<?php
	class Site {
		//clean up methods
		public static function TrimEdge($string='', $character=''){
			$task = trim($string);
			$task = preg_replace('/\s+/', '', $task);
			if(!empty($character)){$task = trim($task, $character);}
			return $task;
		}

		public static function StringSwap($subject='', $search='', $replace='', $occurence='all'){
			$isfound = strstr($subject, $search);
			if(!$isfound){$task = $subject;}
			else {
				if($occurence=='all'){$task = str_replace($search, $replace, $subject);}
				else {
					if($occurence=='first'){$pos = strpos($subject, $search);}
					if($occurence=='last'){$pos = strrpos($subject, $search);}
					if($pos !== false){$task = substr_replace($subject, $replace, $pos, strlen($search));}
					else {$task = $subject;}
				}
			}
			return $task;
		}

		public static function URL(){
			$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    		$url = strtolower($_SERVER['HTTP_HOST']);
			return $protocol.self::TrimEdge($url);
		}

		public static function DomainURL($domain=''){
			if(empty($domain)){$domain = self::URL();}
			$domain = self::StringSwap($domain, 'https://', '', 'first');
			$domain = self::StringSwap($domain, 'http://', '', 'first');
			return self::TrimEdge(strtolower($domain));
		}

		public static function Domain($domain=''){
			if(empty($domain)){$domain = self::DomainURL();}
			$domain = self::StringSwap($domain, 'www.', '', 'first');
			$domain = self::StringSwap($domain, 'mail.', '', 'first');
			$domain = self::StringSwap($domain, 'smtp.', '', 'first');
			$domain = self::StringSwap($domain, 'pop.', '', 'first');
			$domain = self::StringSwap($domain, 'ftp.', '', 'first');
			$domain = self::StringSwap($domain, 'en.', '', 'first');
			$domain = self::StringSwap($domain, 'mx.', '', 'first');
			$domain = self::StringSwap($domain, '/', '', 'last');
			return self::TrimEdge(strtolower($domain));
		}

		public static function Name($name=''){
			if(empty($name)){$name = self::Domain();}
			$name = str_replace('.com', '', $name);
			$name = str_replace('.org', '', $name);
			$name = str_replace('.net', '', $name);
			$name = str_replace('.ng', '', $name);
			$name = str_replace('.ga', '', $name);
			$name = str_replace('.tk', '', $name);
			$name = str_replace('.io', '', $name);

			$name = trim($name);
			$name = mb_convert_case($name.' ', MB_CASE_TITLE, "UTF-8");
			return self::TrimEdge($name);
		}

	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Welcome to <?php echo Site::Name();?></title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<meta name="description" content="<?php echo Site::Name();?> - <?php echo Site::URL();?>">
		<meta name="keywords" content="<?php echo Site::Name();?>, <?php echo Site::Domain();?>, Web Hosting by OIAVO™ Hosting">
		<link rel="icon" href="favicon.ico">
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<style type="text/css" media="screen">
		.hide {position: absolute; overflow: hidden; clip: rect(0 0 0 0); height: 1px; width: 1px; margin: -1px; padding: 0; border: 0;}			
		</style>
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><?php echo Site::Name();?>™ <span class="hide"> - <?php echo Site::Name();?> hosted by OIAVO™ Hosting</span></h1>				
				<p><?php echo ucfirst(Site::Domain());?> has launched<br>
				We encourage you to visit again while we review our design<br>
				Thank you for dropping by.</p>
			</header>

		<!-- Footer -->
			<footer id="footer">
			<span style="font-weight: normal; font-family: 'Trebuchet MS', Arial, Verdana, sans-serif">Get premium web hosting & domain registration at <a href="http://www.oiavo.net/?ref=<?php echo Site::DomainURL();?>" target="_blank">OIAVO Hosting</a></span>
				<ul class="icons">
					<li><a href="http://facebook.com/oiavo" class="icon fa-facebook" target="_blank"><span class="label">Facebook</span></a></li>
					<li><a href="http://twitter.com/oiavo" class="icon fa-twitter" target="_blank"><span class="label">Twitter</span></a></li>
					<li><a href="http://social.oiavo.com/gplus" class="icon fa-google-plus" target="_blank"><span class="label">Google+</span></a></li>
					<li><a href="https://www.linkedin.com/company/oiavo" class="icon fa-linkedin" target="_blank"><span class="label">LinkedIn</span></a></li>
					<li><a href="http://instagram.com/oiavo" class="icon fa-instagram" target="_blank"><span class="label">Instagram</span></a></li>
					<li><a href="http://youtube.com/oiavo" class="icon fa-youtube" target="_blank"><span class="label">Youtube</span></a></li>
					<li><a href="http://github.com/oiavo" class="icon fa-github" target="_blank"><span class="label">GitHub</span></a></li>
				</ul>
				<ul class="copyright">
					<li>&copy; <?php echo Site::Name().' '.date('Y');?></li>
					<li><a href="<?php echo Site::URL();?>"><?php echo Site::DomainURL();?></a> is hosted by <a href="http://www.oiavo.net/?ref=<?php echo Site::DomainURL();?>" target="_blank">OIAVO</a>™</li>
				</ul>
			</footer>

		<!-- Scripts -->
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>