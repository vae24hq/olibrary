		<div class="container-fluid">

			<!-- Page Heading -->
			<h1 class="h3 mb-2 text-gray-800">Patient List</h1>
			<!-- DataTales Example -->
			<div class="card shadow mb-4">
			<div class="card-header py-3">
				<P class="m-0 font-weight-bold text-primary"><a href="patient-new" class="odao-navspace">New Patient</a> | <a href="patient-list" class="odao-navspace">View Patient</a></P>
			</div>
			<div class="card-body">
				<div class="table-responsive">
				<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
					<thead>
					<tr>
						<th data-field="name" data-sortable="true" class="col-md-4">Name</th>
						<th data-field="id" data-sortable="true" class="col-md-2">Hospital No</th>
						<th data-field="email"  data-sortable="true">Email</th>
						<th data-field="phone" data-sortable="true">Phone No</th>
						<th class="col-md-2">Manage</th>

					</tr>
					</thead>
					<tbody>
							<tr>
							<td>Tiger Nixon</td>
							<td>FTH/111</td>
							<td>john@yahoo.com</td>
							<td>08138383838</td>
							</tr>
							<tr>
								<td>Garrett Winters</td>
								<td>FTH/111</td>
								<td>john@yahoo.com</td>
								<td>08138383838</td>
							</tr>
							<tr>
								<td>Ashton Cox</td>
								<td>FTH/111</td>
								<td>john@yahoo.com</td>
								<td>08138383838</td>
								
							</tr>
					</tbody>
				</table>
				</div>
			</div>
			</div>

		</div>


	