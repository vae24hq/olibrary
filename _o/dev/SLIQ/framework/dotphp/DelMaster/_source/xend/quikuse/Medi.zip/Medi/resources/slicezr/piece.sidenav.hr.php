			<!-- Divider -->
			<hr class="sidebar-divider">

			<!-- Heading -->
			<!-- <div class="sidebar-heading">Human Resource</div> -->

			<!-- Nav Item - Pages Collapse Menu -->
			<li class="nav-item">
				<a class="nav-link" href="#" data-toggle="collapse" data-target="#collapseHR" aria-expanded="true" aria-controls="collapseHR">
					<i class="fas fa-fw fa-folder"></i>
					<span>Human Resource</span>
				</a>
				<div id="collapseHR" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
					<div class="bg-white py-2 collapse-inner rounded">
						<h6 class="collapse-header">Manage Staff</h6>
						<a class="collapse-item" href="staff-new"><i class="fas fa-fw fa-user-plus"></i> New Staff</a>
						<a class="collapse-item" href="staff-list"><i class="fas fa-fw fa-user-friends"></i> Staff List</a>
					</div>
				</div>
			</li>