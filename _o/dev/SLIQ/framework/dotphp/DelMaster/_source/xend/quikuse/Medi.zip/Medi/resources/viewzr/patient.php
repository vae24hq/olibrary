			
				<div class="container-fluid">

					<!-- Page Heading -->
					<h1 class="h3 mb-2 text-gray-800">Patient</h1>


					<!-- Content Row -->
					<div class="row">

						<div class="col-md-12">

							<!-- Area Chart -->
							<div class="card shadow mb-4">
								<div class="card-header py-3">
									<h6 class="m-0 font-weight-bold text-primary">Patient Record</h6>
								</div>
								<div class="card-body">

									<form name="NewPatient" id="NewPatient" action="patient-edit?patient=<?php echo $_GET['patient'];?>" method="post">
										<div class="row">
											<div class="col-sm-12" align="center">
												<br>
											</div>
										
											<div class="col-sm-4" align="center">
												<img alt="Picture" src="http://thispix.com/wp-content/uploads/2015/06/passport-005.jpg" width="150" height="150">
												<h5 style="margin-top: 0.3em;">JOHN BRIGHT DOE</h5>
												<dt>Hospital No:</dt>
												<dd>FTH/100</dd>
												
											</div>
										
											<div class="col-sm-8">
												<dl class="dl-horizontal">
													<dt>Hospital No:</dt>
													<dd>FTH/100</dd>
													<dt>Name:</dt>
													<dd>JOHN BRIGHT DOE</dd>
													<dt>Occupation:</dt>
													<dd>Teacher</dd>
													<dt>Phone number:</dt>
													<dd>+234803867721</dd>
													<dt>Email Address:</dt>
													<dd>john@yahoo.com</dd>
													<dt>Nationality:</dt>
													<dd>Nigerian</dd>
													<dt>Tribe:</dt>
													<dd>Benin</dd>
													<dt>Religion:</dt>
													<dd>Islam</dd>
													<dt>HMO:</dt>
													<dd>Hygiea</dd>
													<dt>Date Of Birth:</dt>
													<dd>26-11-2019</dd>
													<dt>Gender:</dt>
													<dd>Male</dd>
													<dt>Address:</dt>
													<dd>3 John Street, Benin, Edo State</dd>
													<dt>Next Of Kin:</dt>
													<dd>Bright Doe</dd>
													<dt>Relationship <small>(with NOK)</small>:</dt>
													<dd>Father</dd>
													<dt>Phone Number <small>(for NOK)</small>:</dt>
													<dd>+234010100001</dd>
													
										
												</dl>
											</div>
										</div>
										<div class="form-row">
											<div class="col-md-6"></div>
											<div class="col-md-3">
												<div class="form-group odao-bottom-button">
													<button type="submit" id="printBTN" name="printBTN" class="btn btn-success odao-button" tabindex="1">Print</button>
												</div>
											</div>
										</div>
										
									</form>

								</div>
							</div>
						</div>
					</div>
				</div>