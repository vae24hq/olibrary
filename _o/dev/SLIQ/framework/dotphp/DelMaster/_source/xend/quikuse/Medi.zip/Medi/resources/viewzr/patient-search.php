
	<form class="col-md-12" style="margin-top: 10%;" action="" method="post">
						<div class="input-group">
								<div class="col-md-2"></div>
								<input type="text" class="form-control col-md-8" placeholder="Search for patients..." aria-label="Search" aria-describedby="basic-addon2">
							<div class="input-group-append">
								<button class="btn btn-primary" type="button">
									<i class="fas fa-search fa-sm"></i>
								</button>
							</div>
								<div class="col-md-2"></div>
						</div>
	</form> 
	
