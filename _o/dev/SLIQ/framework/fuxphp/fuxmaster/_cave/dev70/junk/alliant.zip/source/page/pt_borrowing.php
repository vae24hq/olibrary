<div id="main">
<img src="source/asset/borrowing.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>Se você está procurando financiamento a curto ou longo prazo para comprar instalações e veículos, nós temos uma solução para você.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/vehicle.jpg" class="flex">
		<h3 class="subheading">Finanças de veículos</h3>
		<p>Quando se trata de comprar um veículo para o seu negócio, podemos ajudar. Nossa gama de pacotes flexíveis de financiamento de veículos significa que podemos oferecer tarifas excelentes, seja seu veículo novo ou usado.</p>
		<p>Se você está olhando para manter seus custos mensais baixos, nós ainda temos planos de Contrato Pessoal. Contacte-nos para encontrar o pacote certo para você.</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/overdraft.jpg" class="flex">
		<h3 class="subheading">Descoberto bancário</h3>
		<p>A maioria das empresas precisa de um descoberto em algum momento para financiamento de curto prazo.
		Nossos descobertos de negócios garantidos e não garantidos são projetados para atender a essas necessidades. E porque os juros só são pagos sobre o valor que você está descoberto, nos dias em que você está descoberto, é uma maneira clara e direta de pedir emprestado</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/business-loan.jpg" class="flex">
		<h3 class="subheading">Empréstimo de negócios</h3>
		<p>Nosso Empréstimo de Pequenas Empresas é a escolha perfeita se você estiver procurando por ajuda para expandir seu negócio. Você pode emprestar de £ 1.000 a £ 25.000 durante um período de 12 meses a 5 anos.</p>
		<p class="spaceTop">Qualquer propriedade usada como segurança, que pode incluir sua casa, pode ser recuperada se você não continuar os reembolsos em sua hipoteca</p>
		</aside>
		</div>
	</div>
</div>
