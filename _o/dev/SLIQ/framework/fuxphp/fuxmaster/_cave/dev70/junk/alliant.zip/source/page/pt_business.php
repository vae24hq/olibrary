<div id="main">
<img src="source/asset/business.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>Uma visão geral de suas diferentes contas eo saldo global é que eles representam um componente importante da gestão efetiva de seu capital.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/corpo.jpg" class="flex">
		<h3 class="subheading">Serviço corporativo</h3>
		<p>Nós nos juntamos com uma série de especialistas líderes em seus campos específicos para fornecer o tipo de serviços que podem realmente beneficiar seu negócio.</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/busi.jpg" class="flex">
		<h3 class="subheading">O negócio</h3>
		<p>Nossa conta lhe dá controle completo com acesso 24 horas por dia à sua conta, seja através de nossas instalações on-line, caixas eletrônicas ou por correio.</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/borrow.jpg" class="flex">
		<h3 class="subheading">Empréstimo</h3>
		<p>Se o seu desejo é para financiamento a curto ou longo prazo, ou para comprar instalações ou veículos, temos uma solução apenas para você, que colocará mais do que um sorriso no seu rosto.</p>
		</aside>
		</div>

	</div>
</div>
