
<div id="topbar" class="group">
	<p class="breadcrumb"><?php echo showBreadcrumb();?></p>
	<p class="lang">
		<a href="?page=<?php echo selfLink();?>&lang=en" class="language">English</a> |
		<a href="?page=<?php echo selfLink();?>&lang=es" class="language">Español</a> |
		<a href="?page=<?php echo selfLink();?>&lang=pt" class="language">Português</a> |
		<a href="?page=<?php echo selfLink();?>&lang=ch" class="language">中文</a> |
		<a href="?page=<?php echo selfLink();?>&lang=ar" class="language">الآن</a>
	</p>
</div>
