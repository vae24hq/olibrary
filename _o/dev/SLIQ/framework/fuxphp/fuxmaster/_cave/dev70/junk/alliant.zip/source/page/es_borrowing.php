<div id="main">
<img src="source/asset/borrowing.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>Si usted está buscando financiación a corto o largo plazo para comprar locales y vehículos, tenemos una solución para usted.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/vehicle.jpg" class="flex">
		<h3 class="subheading">Finanzas de vehículos</h3>
		<p>Cuando se trata de comprar un vehículo para su negocio, podemos ayudar. Nuestra gama de paquetes flexibles de financiación de vehículos significa que podemos ofrecer grandes tarifas, ya sea que su vehículo sea nuevo o usado.</p>
		<p>Si usted está buscando para mantener sus costos mensuales, incluso tenemos planes de contrato personal. Póngase en contacto con nosotros para encontrar el paquete adecuado para usted.</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/overdraft.jpg" class="flex">
		<h3 class="subheading">Sobregiro bancario</h3>
		<p>La mayoría de las empresas necesitan un sobregiro en algún momento para financiamiento a corto plazo.
		Nuestros descubiertos de negocios asegurados y no garantizados están diseñados para satisfacer estas necesidades. Y debido a que el interés sólo se paga sobre la cantidad que está sobregirado, en los días que está sobregirado, es una forma clara y directa de pedir prestado</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/business-loan.jpg" class="flex">
		<h3 class="subheading">Préstamo de Negocios</h3>
		<p>Nuestro préstamo de la pequeña empresa es la opción perfecta si usted está buscando ayuda para crecer su negocio. Usted puede pedir prestado de £ 1,000 a £ 25,000 sobre un término de 12 meses a 5 años.</p>
		<p class="spaceTop">Cualquier propiedad usada como garantía, que puede incluir su hogar, puede ser recuperada si no mantiene los pagos en su hipoteca</p>
		</aside>
		</div>
	</div>
</div>
