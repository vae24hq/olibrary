<div id="main">
<img src="source/asset/mortgages.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>获奖者您的钱最佳直接贷款奖2010年第三年运行，还有您的抵押贷款最佳再按揭贷款奖2010/2011第二年运行。</p>
		</article>

		<div class="group">
		<aside id="paid">
		<h3 class="none">3.59％ - 2年固定利率</h3>
		<p>3.59％ - 2年固定利率<br>
		对于抵押贷款客户，<br>
		然后改为我们的标准变动率目前为4.24％<br>
		比较的总成本为4.3％</p>
		<ul><b>特征</b>
		<li>固定利率期间提前还款费用。</li>
		<li>最高贷款额度100万英镑</li>
		</ul>
		</aside>

		<aside id="cash">
		<h3 class="none">5.45% - 2年固定利率</h3>
		<p>5.45% - 2年固定利率<br>
		移动商和首次采购商<br>
		然后改为我们的标准变动率目前为4.24％<br>
		比较的总成本为4.6％的APR</p>
		<ul><b>特征</b>
		<li>固定利率期间提前还款费用。</li>
		<li>最低押金需10％</li>
		<li>最大贷款额度25万英镑</li>
		</ul>
		</aside>
		</div>
	</div>
</div>
