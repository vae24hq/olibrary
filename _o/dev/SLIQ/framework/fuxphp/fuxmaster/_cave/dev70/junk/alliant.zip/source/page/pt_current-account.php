<div id="main">
<img src="source/asset/current.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.ucwords(cleanUp(getPage()));?></h2>
		<p>A conta corrente Alliant foi projetada para você.<br>
		Nós possuímos uma variedade de contas atuais para atender a todas as necessidades - quer você queira ganhar alto interesse em seu dinheiro, ou use regularmente um descoberto, quer uma conta com benefícios adicionais ou simplesmente quer uma conta bancária direta. Também temos contas para Estudantes e menores de 18 anos.</p>

		<p class="spaceTop">Se você é inovador e investir constantemente em novas ferramentas para manter ou aumentar a produtividade do seu negócio. Oferecemos uma gama de soluções, adaptadas às suas necessidades e seus requisitos.</p>
		</article>

		<div class="group">
		<aside id="paid">
		<h3 class="subheading">Nova conta</h3>
		<p>Nossa conta corrente diária é apenas isso - uma conta para todos os dias. Você obterá todos os recursos que você esperaria.</p>
		<p>Isso inclui:<br>
		Um descoberto detalhado (dependendo das circunstâncias)<br>
		Serviços de banca bancária e telefônica on-line 24 horas.</p>
		</aside>

		<aside id="cash">
		<h3 class="subheading">Recompensa do Cliente</h3>
		<p>Recompensa para os clientes que se juntam a nós:<br>
		5% AER (fixo) por 12 meses em saldos até £ 2,500 quando você paga em pelo menos £ 1.000 por mês<br>
		Você recebe reembolso de £ 100 e 0% EAR (variável) de descoberto.<br>
		Não há taxas diárias de descoberto por período de 12 meses</p>
		</aside>
		</div>
	</div>
</div>
