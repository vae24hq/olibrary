<div id="sidebar">
	<img src="source/asset/contact-side.jpg" class="flex">
	<div class="sidebar">
	<h4 class="heading">联系我们</h4>
	<div class="content">
		<p><b>办公地址</b><br>
		公司总部<br>
		13 West Alisal St,<br>CA 53916,California C31,<br>United States<br><br>
		<b>营业时间：</b> <br>
		周一至周五上午8时至晚上8时<br>
		上午10点 - 下午4点周末和节假日<br><br>
		给我们打电话:<br> <b>+1 (315) 688 1528</b><br><br>
		你可以发电子邮件:<br> <b>info@<?php echo getDomain();?></b>
		</p>
	</div>
	</div>
</div>
