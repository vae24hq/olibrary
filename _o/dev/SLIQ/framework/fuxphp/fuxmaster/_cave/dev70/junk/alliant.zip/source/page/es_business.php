<div id="main">
<img src="source/asset/business.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>Una visión general de sus diferentes cuentas y el equilibrio general es que representan un componente importante de la gestión eficaz de su capital.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/corpo.jpg" class="flex">
		<h3 class="subheading">Servicio corporativo</h3>
		<p>Nos hemos reunido con un número de expertos líderes en sus campos particulares para ofrecerle el tipo de servicios que realmente pueden beneficiar a su negocio.</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/busi.jpg" class="flex">
		<h3 class="subheading">Negocio</h3>
		<p>Nuestra cuenta le da un control completo con acceso las veinticuatro horas a su cuenta ya sea a través de nuestras instalaciones en línea, cajeros automáticos o por correo.</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/borrow.jpg" class="flex">
		<h3 class="subheading">Préstamo</h3>
		<p>Si su deseo es para financiar a corto o largo plazo, o para comprar locales o vehículos, tenemos una solución sólo para usted, que pondrá más de una sonrisa en su cara.</p>
		</aside>
		</div>

	</div>
</div>
