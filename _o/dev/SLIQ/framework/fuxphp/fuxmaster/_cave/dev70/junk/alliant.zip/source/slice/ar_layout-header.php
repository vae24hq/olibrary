
<div class="header">
<header id="header" class="group">
<div class="branding">
	<span><a href="./" title="<?php global $qs_name; echo $qs_name;?>" class="logo"><img src="source/asset/logo.png"></a></span>
	<span class="slogan">يمكنك البنك علينا</span>
</div>

<div class="aside">
	<span><b>الخدمات المصرفية الإلكترونية</b>
	<a href="<?php echo IB('login');?>" target="_blank" title="تسجيل الدخول" class="login" onclick="openIB('login');return false;">تسجيل الدخول</a><a href="<?php echo IB('register');?>" target="_blank" title="تسجيل" class="signup" onclick="openIB('register');return false;">تسجيل</a>
	</span>
</div>
</header>
</div>