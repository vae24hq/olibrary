
<div class="header">
<header id="header" class="group">
<div class="branding">
	<span><a href="./" title="<?php global $qs_name; echo $qs_name;?>" class="logo"><img src="source/asset/logo.png"></a></span>
	<span class="slogan">你可以在我们的银行</span>
</div>

<div class="aside">
	<span><b>电子银行</b>
	<a href="<?php echo IB('login');?>" target="_blank" title="登录" class="login" onclick="openIB('login');return false;">登录</a><a href="<?php echo IB('register');?>" target="_blank" title="寄存器" class="signup" onclick="openIB('register');return false;">寄存器</a>
	</span>
</div>
</header>
</div>
