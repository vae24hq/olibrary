<div id="main">
<img src="source/asset/savings.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>Buscamos uma lista de provedores para encontrar a cotação mais barata e temos call centers amigáveis. Nossa linha está aberta 24 horas por dia, 365 dias por ano, então você não precisa se preocupar se algo inesperado acontecer. Por favor, note que os termos e condições são aplicáveis.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/regular.jpg" class="flex">
		<h3 class="subheading">Poupança regular</h3>
		<p>Você receberá uma taxa fixa de 6% de AER / bruto se você for um cliente Premier ou Advance.</p>
		<p>Você receberá uma taxa fixa de 4% AER / bruto se você for um cliente da Conta Mensal ou Pós-Graduada</p>
		<p>Você pode optar por configurar uma ordem permanente para pagar entre £ 25 e £ 250 em sua conta de poupança regular a cada mês, até um total de £ 3.000</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/fixed.jpg" class="flex">
		<h3 class="subheading">Taxas Fixas</h3>
		<p>Você escolhe um termo de depósito que você gosta</p>
		<p>Você pode depositar qualquer coisa de £ 2.000 a £ 1.000.000. O dinheiro está trancado no vínculo durante todo o período.<br>
		A taxa de juros depende do valor que você depositar e da duração do prazo. Como a taxa é fixada antecipadamente, você sabe exatamente quanto você ganhará no final do prazo.</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/cashisa.jpg" class="flex">
		<h3 class="subheading">Cash ISA</h3>
		<p>Abra uma conta em poucos minutos e seja recompensado pela sua lealdade quando você paga pelo menos £ 1 no ISA a cada ano.<br>
		A taxa de fidelidade variável aplica-se por 12 meses * a partir da data de cada pagamento.</p>
		<p>Após o termo do seu período de Taxa de Lealdade, você ganhará uma taxa de juros padrão até você efetuar um pagamento adicional. Disponível exclusivamente para nossos clientes.</p>
		</aside>
		</div>

	</div>
</div>
