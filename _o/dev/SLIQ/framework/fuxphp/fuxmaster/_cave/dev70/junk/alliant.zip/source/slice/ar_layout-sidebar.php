<div id="sidebar">
	<img src="source/asset/contact-side.jpg" class="flex">
	<div class="sidebar">
	<h4 class="heading">اتصل بنا</h4>
	<div class="content">
		<p><b>عنوان المكتب</b><br>
		مقر الشركة<br>
		13 West Alisal St,<br>CA 53916,California C31,<br>United States<br><br>
		<b>ساعات العمل:</b> <br>
		8 صباحا - 8 مساء من الاثنين إلى الجمعة<br>
		10 صباحا - 4 مساء عطلة نهاية الأسبوع والعطلات.<br><br>
		رقم الهاتف:<br> <b>+1 (315) 688 1528</b><br><br>
		يمكنك مراسلتنا عبر البريد الإلكتروني:<br> <b>info@<?php echo getDomain();?></b>
		</p>
	</div>
	</div>
</div>
