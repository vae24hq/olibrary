<nav id="nav" class="group">
<h2 class="none">Navigation</h2>
<ul class="menu">
	<li><?php echo makeLink('navlink', 'index', 'casa');?></li>
	<li><?php echo makeLink('navlink', 'private', 'banca privada');?></li>
	<li><?php echo makeLink('navlink', 'corporate', 'corporativo');?></li>
	<li><?php echo makeLink('navlink', 'business', 'Banca de negocios');?></li>
	<li><?php echo makeLink('navlink', 'savings', 'ahorros');?></li>
	<li><?php echo makeLink('navlink', 'current-account', 'cuenta actual');?></li>
	<li><?php echo makeLink('navlink', 'insurance', 'seguro');?></li>
	<li><?php echo makeLink('navlink', 'borrowing', 'préstamo');?></li>
	<li><?php echo makeLink('navlink', 'mortgages', 'Hipotecas');?></li>
</ul>
</nav>

<div id="contentbox" class="group">
