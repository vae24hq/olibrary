<div id="main">
<img src="source/asset/insurance.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>Buscamos uma lista de provedores para encontrar a cotação mais barata e temos call centers amigáveis. Nossa linha está aberta 24 horas por dia, 365 dias por ano, então você não precisa se preocupar se algo inesperado acontecer. Por favor, note que os termos e condições são aplicáveis.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/inscar.jpg" class="flex">
		<h3 class="subheading">Seguro de auto</h3>
		<p>Gratis Tom Sat Nav vale £ 99.99 cuando usted toma una nueva póliza de seguro de coche con nosotros. Buscamos un panel de aseguradores para encontrar nuestra cotización más barata, por lo que no es necesario. Esta oferta está sujeta a disponibilidad y puede ser retirada en cualquier momento</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/instravel.jpg" class="flex">
		<h3 class="subheading">Seguro de viaje</h3>
		<p>Usted puede elegir la cubierta para satisfacer sus necesidades. Usted puede elegir de viaje único o anual de varios viajes europeo o mundial y si usted necesita cubierta de deportes de invierno que podemos hacer eso también. Obtendrá gastos médicos ilimitados y una cobertura instantánea si lo necesita.</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/inshome.jpg" class="flex">
		<h3 class="subheading">Seguro de hogar</h3>
		<p>Si desea proteger su edificio, el contenido o ambos, nuestro seguro de alta calidad ofrece la cobertura que necesita para las cosas que le importan. Disponible sólo para nuevos clientes.</p>
		</aside>
		</div>
	</div>
</div>
