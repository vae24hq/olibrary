<div id="main">
<?php loadFile('layout-slide', 'slice');?>
	<div class="content">
		<article id="index">
		<h2 class="heading"><?php global $qs_name; echo $qs_name;?></h2>
		<p>Nuestro paquete de negocios es más que una cuenta. Los servicios personalizados adicionales para profesionales independientes y empresas le ayudan a simplificar la gestión financiera de su negocio o empresa.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/corpi.jpg" class="flex">
		<h3 class="subheading">Corporativo</h3>
		<p>Nos hemos reunido con un número de expertos líderes en sus campos particulares para ofrecerle el tipo de servicios que realmente pueden beneficiar a su negocio.</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/borrow.jpg" class="flex">
		<h3 class="subheading">Préstamo</h3>
		<p>Si su deseo es para financiar a corto o largo plazo, o para comprar locales o vehículos, tenemos una solución sólo para usted, que pondrá más de una sonrisa en su cara.</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/busi.jpg" class="flex">
		<h3 class="subheading">Banca Comercial</h3>
		<p>Nuestra cuenta le da un control completo con acceso las veinticuatro horas a su cuenta ya sea a través de nuestras instalaciones en línea, cajeros automáticos o por correo.</p>
		</aside>
		</div>
	</div>
</div>
