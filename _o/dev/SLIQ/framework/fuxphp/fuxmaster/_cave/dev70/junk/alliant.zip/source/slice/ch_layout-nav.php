<nav id="nav" class="group">
<h2 class="none">Navigation</h2>
<ul class="menu">
	<li><?php echo makeLink('navlink', 'index', '家');?></li>
	<li><?php echo makeLink('navlink', 'private', '私人银行');?></li>
	<li><?php echo makeLink('navlink', 'corporate', '企业银行');?></li>
	<li><?php echo makeLink('navlink', 'business', '商业银行');?></li>
	<li><?php echo makeLink('navlink', 'savings', '储蓄账户');?></li>
	<li><?php echo makeLink('navlink', 'current-account', '经常账户');?></li>
	<li><?php echo makeLink('navlink', 'insurance', '保险');?></li>
	<li><?php echo makeLink('navlink', 'borrowing', '贷款');?></li>
	<li><?php echo makeLink('navlink', 'mortgages', '抵押贷款');?></li>
</ul>
</nav>

<div id="contentbox" class="group">
