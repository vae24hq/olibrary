<div id="main">
<img src="source/asset/insurance.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>我们搜索提供商列表，找到最便宜的报价，我们有友好的呼叫中心。 我们的线路每天24小时开放，每年365天，所以如果发生意外事故，您不必担心。 请注意条款和条件适用。</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/inscar.jpg" class="flex">
		<h3 class="subheading">为你的车</h3>
		<p>当我们与我们签订新的汽车保险政策时，免费的Tom Sat Nav值得£99.99。 我们搜索一组保险公司找到我们最便宜的报价，所以你不必。 此优惠视供应情况而定，并可随时撤销</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/instravel.jpg" class="flex">
		<h3 class="subheading">旅游保险</h3>
		<p>您可以选择封面以满足您的需求。 您可以选择单程旅行或每年多次欧洲或全球封面，如果您需要冬季运动护具，我们也可以做到这一点。 如果需要，您将获得无限的医疗费用和即时覆盖。</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/inshome.jpg" class="flex">
		<h3 class="subheading">你家的保险</h3>
		<p>无论您想保护您的建筑物，内容还是保护您的高品质保险，您都能为您提供所需的保护。
		此服务仅适用于新客户。</p>
		</aside>
		</div>
	</div>
</div>
