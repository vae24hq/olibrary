<div id="main">
<?php loadFile('layout-slide', 'slice');?>
	<div class="content">
		<article id="index">
		<h2 class="heading"><?php global $qs_name; echo $qs_name;?></h2>
		<p>该 <?php global $qs_acronym; echo $qs_acronym;?> 业务不仅仅是一个帐户。 独立专业人员和公司的其他定制服务可帮助您简化您的业务或公司的财务管理。</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/corpi.jpg" class="flex">
		<h3 class="subheading">公司服务</h3>
		<p>我们与一些领先的专家在一起，为您提供真正有益于您的业务的服务类型。</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/borrow.jpg" class="flex">
		<h3 class="subheading">借款</h3>
		<p>无论您的愿望是短期或长期的融资，还是购买房屋或车辆，我们都将为您提供一个解决方案，这将不仅仅是让您的脸上露出微笑。</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/busi.jpg" class="flex">
		<h3 class="subheading">商业银行</h3>
		<p>我们的帐户可以通过我们的在线设施，自动取款机或邮寄方式全天候访问您的帐户。</p>
		</aside>
		</div>
	</div>
</div>
