<div id="main">
<img src="source/asset/current.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.ucwords(cleanUp(getPage()));?></h2>
		<p>La cuenta corriente de Alliant está diseñada para usted.<br>
		Tenemos una amplia gama de cuentas corrientes para satisfacer todas las necesidades, ya sea que desee ganar un alto interés en su dinero, o usar un sobregiro regularmente, desear una cuenta con beneficios adicionales o simplemente desear una cuenta bancaria directa. También tenemos cuentas para estudiantes y menores de 18 años.</p>

		<p class="spaceTop">Si eres innovador e inviertes constantemente en nuevas herramientas para mantener o aumentar la productividad de tu negocio. Ofrecemos una gama de soluciones, adaptadas a sus necesidades y sus necesidades.</p>
		</article>

		<div class="group">
		<aside id="paid">
		<h3 class="subheading">Nueva cuenta</h3>
		<p>Nuestra cuenta corriente todos los días es sólo eso - una cuenta para todos los días. Obtendrá todas las características que usted esperaría.</p>
		<p>Esto incluye:<br>
		Un sobregiro dispuesto (dependiendo de las circunstancias)<br>
		24 horas de banca en línea y servicios bancarios por teléfono.</p>
		</aside>

		<aside id="cash">
		<h3 class="subheading">Recompensa del cliente</h3>
		<p>Recompensa para los clientes que se unan a nosotros:<br>
		5% AER (fijo) por 12 meses en saldos de hasta £ 2.500 cuando usted paga por lo menos £ 1.000 cada mes<br>
		Se obtiene un reembolso de 100 libras esterlinas y un 0% de sobregiro EAR (variable).<br>
		No Diario Arreglado por 12 meses</p>
		</aside>
		</div>
	</div>
</div>
