<div id="main">
<img src="source/asset/corp.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>资金流动的管理并不总是玫瑰床，特别是如果贵公司也在国外活跃. 也, <?php echo $qs_acronym;?> 提供了几种仪器，让您可以顺利地修复一切。
		我们为您的主要关注点提供一系列日常管理的可能性：支付和支付。</p>

		<p class="spaceTop">您是创新的，您将不断投资于新工具，以维持或提高您的业务的生产力。 我们提供一系列解决方案，适合您的需求和您的要求。</p>
		</article>

		<div class="group">
		<aside id="paid">
		<img src="source/asset/get-paid.jpg" class="flex">
		<h3 class="subheading">付款并获得付款</h3>
		<p>虽然转移仍然在B2B关系中; 交易结算最常见的模式，还有其他付款方式和有趣的规则。 无论你选择什么，<?php echo $qs_acronym;?> 我们总是在英国和国外在你身边。</p>
		</aside>

		<aside id="cash">
		<img src="source/asset/cash-management.jpg" class="flex">
		<h3 class="subheading">现金管理</h3>
		<p>您在英国和海外的不同账户的总体情况以及总体平衡是它们是您的首都有效管理的重要组成部分。</p>
		</aside>
		</div>
	</div>
</div>
