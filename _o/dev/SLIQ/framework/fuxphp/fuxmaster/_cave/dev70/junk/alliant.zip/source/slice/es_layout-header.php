
<div class="header">
<header id="header" class="group">
<div class="branding">
	<span><a href="./" title="<?php global $qs_name; echo $qs_name;?>" class="logo"><img src="source/asset/logo.png"></a></span>
	<span class="slogan">Usted puede depositar en nosotros</span>
</div>

<div class="aside">
	<span><b>Banca electrónica</b>
	<a href="<?php echo IB('login');?>" target="_blank" title="Iniciar sesión" class="login" onclick="openIB('login');return false;">Iniciar sesión</a><a href="<?php echo IB('register');?>" target="_blank" title="Registro" class="signup" onclick="openIB('register');return false;">Registro</a>
	</span>
</div>
</header>
</div>
