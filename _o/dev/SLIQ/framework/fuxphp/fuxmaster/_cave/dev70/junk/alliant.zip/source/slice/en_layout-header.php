
<div class="header">
<header id="header" class="group">
<div class="branding">
	<span><a href="./" title="<?php global $qs_name; echo $qs_name;?>" class="logo"><img src="source/asset/logo.png" class="logoImg"></a></span>
	<span class="slogan"><?php global $qs_slogan; echo $qs_slogan;?></span>
</div>

<div class="aside">
	<span><b>e-Banking»</b>
	<a href="<?php echo IB('login');?>" target="_blank" title="login" class="login" onclick="openIB('login');return false;">Login</a><a href="<?php echo IB('register');?>" target="_blank" title="sign up" class="signup" onclick="openIB('register');return false;">Sign Up</a>
	</span>
</div>
</header>
</div>
