<?php
function isSecure($answer='detect'){
	$resolve = false;
	if($answer == 'yeah'){$resolve = true;}
	elseif($answer == 'nope'){$resolve = false;}
	else {//detect from server			
		$https = 'off';
		if(isset($_SERVER['HTTPS']) && !empty($_SERVER['HTTPS'])){$https = $_SERVER['HTTPS'];}
		if($https !== 'off'){$https == 'on';}

		$port = 'default';
		if(isset($_SERVER['SERVER_PORT']) && !empty($_SERVER['SERVER_PORT'])){$port = $_SERVER['SERVER_PORT'];}

		if($https == 'on' || $port == 443){$resolve = true;}
		elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on'){$resolve = true;}
	}
	return $resolve;
}

function imposeSSL($as=''){
	$protocol = isSecure() ? 'https' : 'http';
	if($protocol != 'https'){
		$url = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
		if($as == 'permanent'){header('HTTP/1.1 301 Moved Permanently');}
		header('Location: ' . $url);
		exit();
	}
}
#imposeSSL();
?>