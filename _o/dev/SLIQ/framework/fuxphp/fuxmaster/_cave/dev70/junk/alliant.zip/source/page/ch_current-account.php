<div id="main">
<img src="source/asset/current.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.ucwords(cleanUp(getPage()));?></h2>
		<p>我们的服务是为您而设计的<br>
		我们有一系列适合各种需求的经常账户 - 无论您想要赚高利息，还是经常使用透支，想要一个额外收益的帐户，或者只需要一个简单的银行账户。 我们也有学生和18岁以下的账户。</p>

		<p class="spaceTop">如果您是创新型企业，并且不断投资新的工具来维持或提高企业的生产力。 我们提供一系列解决方案，适合您的需求和您的要求。</p>		
		</article>

		<div class="group">
		<aside id="paid">
		<h3 class="subheading">新银行账户</h3>
		<p>我们的日常经常帐户就是这样 - 每天都有帐户。 你会得到你期望的所有功能。</p>
		<p>这包括:<br>
		安排透支（视情况而定）<br>
		24小时银行 - 在线和电话银行服务。</p>
		</aside>

		<aside id="cash">
		<h3 class="subheading">奖励客户</h3>
		<p>奖励切换到我们的客户:<br>
		5％AER（固定）为12个月，平衡达2,500英镑，当您每月支付至少£1,000
		<br>
		您将获得100英镑的现金回报和0％的EAR（可变）透支。<br>
		没有每日安排透支费用12个月</p>
		</aside>
		</div>
	</div>
</div>
