<div id="main">
<img src="source/asset/private.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>Usted tiene una herencia de más de 500 000 euros que desea proteger y crecer. Para ello, puede ponerse en contacto con su banquero en su oficina local. Le ayuda a administrar, organizar e incluso transferir sus activos de manera óptima, teniendo en cuenta su personalidad y su situación específica. Y con todas las soluciones que un gran banco puede ofrecer. En suma, una rica visión de sus activos.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/sav.jpg" class="flex">
		<h3 class="subheading">Ahorros</h3>
		<p>Con nuestra amplia gama de bonos de ahorros a tasa fija puede ahorrar en el conocimiento de que su tasa es fija. Con una selección de términos fijos disponibles, hacemos los ahorros fáciles de operar.</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/mort.jpg" class="flex">
		<h3 class="subheading">Hipotecas</h3>
		<p>Comprar una nueva casa debe ser una experiencia agradable. Nos gustaría ayudarlo a hacerlo de esa manera tomando la preocupación de solicitar una hipoteca para una nueva casa o una casa previamente poseída</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/curr.jpg" class="flex">
		<h3 class="subheading">Cuenta actual</h3>
		<p>Tenemos una gama de cuentas corrientes para satisfacer cada necesidad - si desea ganar un alto interés en su dinero, o utilizar regularmente un sobregiro simplemente quiere una cuenta directa</p>
		</aside>
		</div>
	</div>
</div>
