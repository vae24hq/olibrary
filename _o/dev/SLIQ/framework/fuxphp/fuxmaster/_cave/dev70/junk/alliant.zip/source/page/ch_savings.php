<div id="main">
<img src="source/asset/savings.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>我们搜索提供商列表，找到最便宜的报价，我们有友好的呼叫中心。
		我们的线路每天24小时开放，每年365天，所以如果发生意外事故，您不必担心。 请注意条款和条件适用。</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/regular.jpg" class="flex">
		<h3 class="subheading">定期储蓄账户</h3>
		<p>如果您是首席或高级客户，您将获得6％的固定利率。</p>
		<p>如果您是“每月帐户”或“研究生账户”客户，您将获得4％的固定利率</p>
		<p>您可以选择建立一个常规订单，每月支付25英镑至250英镑的常规保护帐户，最多可达3,000英镑。</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/fixed.jpg" class="flex">
		<h3 class="subheading">固定利率</h3>
		<p>您选择固定利率保释债券的存款期限。</p>
		<p>您可以从2,000英镑到1,000,000英镑存款。 这笔钱在整个期限内被锁定在债券中。<br>
		利率取决于您存入的金额和期限的长短。 由于费率是事先确定的，所以您将明确知道在该期限结束之前您将赚取多少利息。</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/cashisa.jpg" class="flex">
		<h3 class="subheading">现金 ISA</h3>
		<p>在几分钟内开立帐户，并在每年支付至少1英镑的ISA中获得奖励。<br>
		从每次付款之日起，变动的忠诚率适用于12个月*。</p>
		<p>在您的忠诚度期限届满后，您将获得标准利率，直到您进一步付款为止。 专为我们的客户提供。</p>
		</aside>
		</div>

	</div>
</div>
