<div id="main">
<img src="source/asset/corp.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>La gestión de los flujos financieros no siempre es una cama de rosas, especialmente si su empresa también está activa en el extranjero. Además, ofrecemos varios instrumentos que le permiten arreglar todo sin problemas. Ofrecemos una gama de posibilidades para la gestión diaria de sus principales preocupaciones: pagar y cobrar.</p>

		<p class="spaceTop">Eres innovador e inviertes constantemente en nuevas herramientas para mantener o aumentar la productividad de tu negocio. Ofrecemos una gama de soluciones, adaptadas a sus necesidades y sus necesidades.</p>
		</article>

		<div class="group">
		<aside id="paid">
		<img src="source/asset/get-paid.jpg" class="flex">
		<h3 class="subheading">Recibir el pago</h3>
		<p>Aunque la transferencia se mantiene en las relaciones B2B; El modo más común de su liquidación de transacciones, hay otras opciones de pago y reglas interesantes. Cualquiera que sea su elección, nuestro banco está a su lado tanto en el Reino Unido como en el extranjero.</p>
		</aside>

		<aside id="cash">
		<img src="source/asset/cash-management.jpg" class="flex">
		<h3 class="subheading">Gestión de efectivo</h3>
		<p>Una visión general de sus diferentes cuentas y el equilibrio general es que representan un componente importante de la gestión eficaz de su capital.</p>
		</aside>
		</div>
	</div>
</div>
