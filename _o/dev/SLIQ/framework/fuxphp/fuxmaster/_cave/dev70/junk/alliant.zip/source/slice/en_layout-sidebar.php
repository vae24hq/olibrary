<div id="sidebar">
	<img src="source/asset/contact-side.jpg" class="flex">
	<div class="sidebar">
	<h4 class="heading">Contact Us</h4>
	<div class="content">
		<p><b>Office Address</b><br>
		Corporate HQ<br>
		13 West Alisal St,<br>CA 53916,California C31,<br>United States<br><br>
		<b>Opening Hours:</b> <br>
		8am - 8pm Monday to Friday<br>
		10am - 4pm Weekends & Holidays.<br><br>
		Phone Number:<br> <b>+1 (315) 688 1528</b><br><br>
		You can email us:<br> <b>info@<?php echo getDomain();?></b>
		</p>
	</div>
	</div>
</div>
