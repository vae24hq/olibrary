</div>

<footer id="footer" class="group">
<span class="copyrightborder"><?php echo showCopyright();?></span>
</footer>
