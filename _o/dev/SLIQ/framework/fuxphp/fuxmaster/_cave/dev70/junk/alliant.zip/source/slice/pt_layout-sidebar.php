<div id="sidebar">
	<img src="source/asset/contact-side.jpg" class="flex">
	<div class="sidebar">
	<h4 class="heading">Contate-Nos</h4>
	<div class="content">
		<p><b>Endereço do escritório</b><br>
		Sede da empresa<br>
		13 West Alisal St,<br>CA 53916,California C31,<br>United States<br><br>
		<b>Horário de funcionamento:</b> <br>
		8h às 20h de segunda a sexta-feira<br>
		10am - 4pm fins de semana e feriados.<br><br>
		Número de telefone: <br><b>+1 (315) 688 1528</b><br><br>
		Você pode nos enviar um e-mail: <br><b>info@<?php echo getDomain();?></b>
		</p>
	</div>
	</div>
</div>
