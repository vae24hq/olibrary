<div id="main">
<img src="source/asset/business.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>لدينا حساب الأعمال رئيس الوزراء هو أكثر من مجرد حساب. خدمات مخصصة إضافية للمهنيين المستقلين والشركات تساعدك على تبسيط الإدارة المالية لعملك أو الشركة.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/corpo.jpg" class="flex">
		<h3 class="subheading">خدمة الشركات</h3>
		<p>لقد وصلنا مع عدد من كبار الخبراء في مجالات معينة لتوفير لكم مع نوع من الخدمات التي يمكن أن تستفيد حقا عملك.</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/busi.jpg" class="flex">
		<h3 class="subheading">الخدمات المصرفية للأعمال</h3>
		<p>حسابنا يتيح لك السيطرة الكاملة مع الوصول على مدار الساعة إلى حسابك إما من خلال مرافقنا على الانترنت، وآلات النقدية أو عن طريق البريد.</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/borrow.jpg" class="flex">
		<h3 class="subheading">الإقراض</h3>
		<p>لا يهم ما إذا كانت رغبتك هي للتمويل القصير أو الطويل الأجل، أو لشراء المباني والمركبات، لدينا حل فقط لأجلك، من شأنها أن تضع أكثر من ابتسامة على وجهك.</p>
		</aside>
		</div>

	</div>
</div>
