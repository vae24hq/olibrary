<div id="sidebar">
	<img src="source/asset/contact-side.jpg" class="flex">
	<div class="sidebar">
	<h4 class="heading">Contáctenos</h4>
	<div class="content">
		<p><b>Dirección de la oficina</b><br>
		Sedes corporativas<br>
		13 West Alisal St,<br>CA 53916,California C31,<br>United States<br><br>
		<b>Horario de apertura:</b> <br>
		De 8am a 8pm de lunes a viernes<br>
		10 am - 4pm fines de semana y vacaciones.<br><br>
		Número de teléfono: <br><b>+1 (315) 688 1528</b><br><br>
		Puede enviarnos un correo electrónico: <br><b>info@<?php echo getDomain();?></b>
		</p>
	</div>
	</div>
</div>
