
<ul class="rslides">
	<li><img src="source/asset/biz.jpg" class="flex"></li>
	<li><img src="source/asset/savings.jpg" class="flex"></li>
	<li><img src="source/asset/mortgages.jpg" class="flex"></li>
	<li><img src="source/asset/business.jpg" class="flex"></li>
	<li><img src="source/asset/current.jpg" class="flex"></li>
	<li><img src="source/asset/corp.jpg" class="flex"></li>
	<li><img src="source/asset/insurance.jpg" class="flex"></li>
	<li><img src="source/asset/private.jpg" class="flex"></li>
	<li><img src="source/asset/borrowing.jpg" class="flex"></li>
</ul>
