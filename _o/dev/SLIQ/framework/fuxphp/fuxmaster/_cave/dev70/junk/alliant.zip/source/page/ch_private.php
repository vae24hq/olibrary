<div id="main">
<img src="source/asset/private.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>你有一个超过50万欧元的遗产，你想保护和成长。 为此，您可以联系当地办事处的银行家。 它可以帮助您最佳地管理，组织，甚至转移您的资产，记录您的个性和具体情况。 以及大银行可以提供的所有解决方案。 总而言之，您的资产的丰富愿景。</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/sav.jpg" class="flex">
		<h3 class="subheading">储</h3>
		<p>通过我们的固定利率储蓄债券，您可以节省您的利率固定的知识。 通过选择可用的固定条款，我们可以节省开支。</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/mort.jpg" class="flex">
		<h3 class="subheading">抵押贷款</h3>
		<p>购买新房应该是一个愉快的经历。 我们希望通过为新房或以前拥有的房屋申请抵押而担心</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/curr.jpg" class="flex">
		<h3 class="subheading">经常账户</h3>
		<p>我们有一系列经常账户来满足每一个需要 - 无论你想赚高利息，还是经常使用透支，只需要一个直接的账户</p>
		</aside>
		</div>
	</div>
</div>
