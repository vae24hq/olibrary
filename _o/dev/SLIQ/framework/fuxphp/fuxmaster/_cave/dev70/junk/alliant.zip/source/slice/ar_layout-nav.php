<nav id="nav" class="group">
<h2 class="none">Navigation</h2>
<ul class="menu">
	<li><?php echo makeLink('navlink', 'index', 'الصفحة الرئيسية');?></li>
	<li><?php echo makeLink('navlink', 'private', 'نشر');?></li>
	<li><?php echo makeLink('navlink', 'corporate', 'الشركات');?></li>
	<li><?php echo makeLink('navlink', 'business', 'الأعمال المصرفية');?></li>
	<li><?php echo makeLink('navlink', 'savings', 'مدخرات');?></li>
	<li><?php echo makeLink('navlink', 'current-account', 'الحساب الحالي');?></li>
	<li><?php echo makeLink('navlink', 'insurance','تأمين');?></li>
	<li><?php echo makeLink('navlink', 'borrowing', 'الإقراض');?></li>
	<li><?php echo makeLink('navlink', 'mortgages', 'القروض العقارية');?></li>
</ul>
</nav>

<div id="contentbox" class="group">
