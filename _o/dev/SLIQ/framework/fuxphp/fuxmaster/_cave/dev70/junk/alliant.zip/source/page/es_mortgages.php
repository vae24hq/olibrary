<div id="main">
<img src="source/asset/mortgages.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>Ganadores de su premio al Mejor Prestamista Directo de Dinero 2010 por tercer año consecutivo y también al Premio al Mejor Prestamista Hipotecario Re-hipotecario 2010/2011 por segundo año consecutivo.</p>	
		</article>

		<div class="group">
		<aside id="paid">
		<h3 class="none">3.59% - 2 años Tarifa fija</h3>
		<p>3,59% - 2 años Tarifa fija<br>
		Para clientes de Re-hipoteca,<br>
		Luego cambiando a nuestra tasa variable estándar actual de 4,24%<br>
		El costo total para la comparación es 4.3% APR</p>
		<ul><b>Caracteristicas</b>
		<li>El cargo de reembolso anticipado se aplica durante el período de tasa fija.</li>
		<li>Tamaño máximo del préstamo £ 1 millón</li>
		</ul>
		</aside>

		<aside id="cash">
		<h3 class="none">5.45% - 2 años Tarifa fija</h3>
		<p>5.45% - 2 años Tarifa fija<br>
		Para los mudadores y compradores por primera vez<br>
		Luego cambiando a nuestra tasa variable estándar actual de 4,24%<br>
		El costo total de comparación es de 4,6% APR</p>
		<ul><b>Caracteristicas</b>
		<li>El cargo de reembolso anticipado se aplica durante el período de tasa fija.</li>
		<li>El depósito mínimo requerido es 10%</li>
		<li>Tamaño máximo del préstamo £ 250,000</li>
		</ul>
		</aside>
		</div>
	</div>
</div>
