<div id="main">
<img src="source/asset/borrowing.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>无论您是寻找短期或长期的融资来购买场所或车辆，我们都有一个解决方案。</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/vehicle.jpg" class="flex">
		<h3 class="subheading">车辆财务</h3>
		<p>当谈到为您的业务购买车辆时，我们可以帮助。 我们的灵活车辆金融包装系列意味着我们可以提供很高的价格，无论您的车辆是新的还是使用的。</p>
		<p>如果您希望保持每月的成本下降，我们甚至会有个人合约计划。 联系我们，为您找到合适的包装。</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/overdraft.jpg" class="flex">
		<h3 class="subheading">银行透支</h3>
		<p>大多数企业在某些时候需要透支短期融资。<br>
		我们的安全无担保业务透支旨在满足这些需求。 而且由于利息只能用于你透支的金额，所以在你透支的日子里，这是一种明确的，直接的借贷方式</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/business-loan.jpg" class="flex">
		<h3 class="subheading">商业贷款</h3>
		<p>如果您正在寻求帮助来发展业务，我们的小企业贷款是完美的选择。 您可以从12个月到5年的期限从1,000英镑借入£25,000。</p>
		<p class="spaceTop">任何用作担保的财产，可能包括您的房屋，如果您不按照您的按揭还款，可能会收回。</p>
		</aside>
		</div>
	</div>
</div>
