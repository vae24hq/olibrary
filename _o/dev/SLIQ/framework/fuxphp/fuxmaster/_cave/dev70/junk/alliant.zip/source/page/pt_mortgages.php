<div id="main">
<img src="source/asset/mortgages.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>Vencedores do seu Prêmio de Melhor Prêmio Diretor de Dinheiro 2010 pelo terceiro ano consecutivo e também o Prêmio de Crédito de Reimportação 2010/2011 pelo seu Mortgage Best pelo segundo ano consecutivo.</p>	
		</article>

		<div class="group">
		<aside id="paid">
		<h3 class="none">3,59% - 2 anos Taxa fixa</h3>
		<p>3,59% - 2 anos Taxa fixa<br>
		Para clientes re-hipoteca,<br>
		Em seguida, mudando para nossa taxa variável padrão atualmente 4,24%<br>
		O custo total de comparação é de 4,3% APR</p>
		<ul><b>Características</b>
		<li>A taxa de reembolso antecipado aplica-se durante o período da taxa fixa.</li>
		<li>Tamanho máximo do empréstimo £ 1 milhão</li>
		</ul>
		</aside>

		<aside id="cash">
		<h3 class="none">5.45% - 2 anos Taxa fixa</h3>
		<p>5.45% - 2 anos Taxa fixa<br>
		Para Movers e First Time Buyers<br>
		Em seguida, mudando para nossa taxa variável padrão atualmente 4,24%<br>
		O custo total de comparação é 4,6% APR</p>
		<ul><b>Características</b>
		<li>A taxa de reembolso antecipado aplica-se durante o período da taxa fixa.</li>
		<li>O depósito mínimo requerido é de 10%</li>
		<li>Tamanho máximo do empréstimo £ 250,000</li>
		</ul>
		</aside>
		</div>
	</div>
</div>
