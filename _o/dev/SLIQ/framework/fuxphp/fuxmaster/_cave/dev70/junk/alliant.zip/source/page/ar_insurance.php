<div id="main">
<img src="source/asset/insurance.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>نحن نبحث عن قائمة من مقدمي لتجد لك أرخص الاقتباس ولدينا مراكز الاتصال ودية. مركز الاتصال لدينا مفتوح 24 ساعة في اليوم، 365 يوما في السنة لذلك لم يكن لديك ما يدعو للقلق إذا حدث شيء غير متوقع.<br>
		يرجى ملاحظة أن تطبق الشروط والأحكام.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/inscar.jpg" class="flex">
		<h3 class="subheading">تأمين سيارتك</h3>
		<p>مجانا توم سات ناف بقيمة 99.99 £ عند اتخاذ سياسة جديدة للتأمين على السيارات مع <?php echo $qs_acronym;?>. نحن البحث في لوحة من شركات التأمين لتجد لك لدينا أرخص الاقتباس، لذلك لم يكن لديك ل. هذا العرض رهن بالتوافر ويمكن سحبه في أي وقت</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/instravel.jpg" class="flex">
		<h3 class="subheading">تأمين السفر</h3>
		<p>يمكنك اختيار غطاء لتناسب احتياجاتك. يمكنك الاختيار من بين رحلة واحدة أو السنوية متعددة رحلة تغطية الأوروبية أو في جميع أنحاء العالم، وإذا كنت بحاجة إلى تغطية الرياضات الشتوية يمكننا أن نفعل ذلك أيضا. ستحصل على نفقات طبية غير محدودة وتغطية فورية إذا كنت في حاجة إليها.</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/inshome.jpg" class="flex">
		<h3 class="subheading">تأمين المنزل</h3>
		<p>إذا كنت ترغب في حماية المبنى الخاص بك، ومحتويات أو كليهما التأمين عالية الجودة يوفر الغطاء الذي تحتاجه للأشياء التي تهمك.<br>هذه الخدمة متاحة فقط للعملاء الجدد.</p>
		</aside>
		</div>
	</div>
</div>
