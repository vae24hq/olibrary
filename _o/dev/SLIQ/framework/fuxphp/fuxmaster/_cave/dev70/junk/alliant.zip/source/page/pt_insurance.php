<div id="main">
<img src="source/asset/insurance.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>Buscamos uma lista de provedores para encontrar a cotação mais barata e temos call centers amigáveis. Nossa linha está aberta 24 horas por dia, 365 dias por ano, então você não precisa se preocupar se algo inesperado acontecer. Por favor, note que os termos e condições são aplicáveis.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/inscar.jpg" class="flex">
		<h3 class="subheading">Seguro de automóvel</h3>
		<p>Tom Sat Nav gratuito vale £ 99,99 quando você tira uma nova apólice de seguro de carro com a gente. Buscamos um painel de seguradoras para encontrar a nossa cotação mais barata, então você não precisa. Esta oferta está sujeita a disponibilidade e pode ser retirada a qualquer momento</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/instravel.jpg" class="flex">
		<h3 class="subheading">Seguro de viagem</h3>
		<p>Você pode escolher a capa de acordo com suas necessidades. Você pode escolher entre uma única viagem ou uma cobertura anual multi-viagem europeia ou mundial e se você precisa de cobertura de esportes de inverno, podemos fazer isso também. Você terá despesas médicas ilimitadas e coberturas instantâneas se você precisar.</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/inshome.jpg" class="flex">
		<h3 class="subheading">Seguro domiciliar</h3>
		<p>Se você quer proteger sua construção, o conteúdo ou o nosso seguro de alta qualidade oferece a cobertura que você precisa para as coisas que são importantes para você. Disponível apenas para novos clientes.</p>
		</aside>
		</div>
	</div>
</div>
