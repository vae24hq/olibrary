<div id="main">
<img src="source/asset/corp.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>A gestão dos fluxos financeiros nem sempre é uma cama de rosas, especialmente se a sua empresa também estiver ativa no exterior. Além disso, oferecemos vários instrumentos que permitem corrigir tudo sem problemas. Oferecemos uma gama de possibilidades para o gerenciamento diário de suas principais preocupações: pagar e receber o pagamento.</p>

		<p class="spaceTop">Você é inovador e você investiga constantemente em novas ferramentas para manter ou aumentar a produtividade do seu negócio. Oferecemos uma gama de soluções, adaptadas às suas necessidades e seus requisitos.</p>
		</article>

		<div class="group">
		<aside id="paid">
		<img src="source/asset/get-paid.jpg" class="flex">
		<h3 class="subheading">Ser pago</h3>
		<p>Embora a transferência permaneça nas relações B2B; O modo mais comum de sua liquidação de transações, existem outras opções de pagamento e regras interessantes. Seja qual for sua escolha, nosso banco está ao seu lado tanto no Reino Unido quanto no exterior.</p>
		</aside>

		<aside id="cash">
		<img src="source/asset/cash-management.jpg" class="flex">
		<h3 class="subheading">Gestão de caixa</h3>
		<p>Uma visão geral de suas diferentes contas eo saldo global é que eles representam um componente importante da gestão efetiva de seu capital.</p>
		</aside>
		</div>
	</div>
</div>
