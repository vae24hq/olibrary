<div id="main">
<img src="source/asset/private.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>Você tem uma herança de mais de 500 000 euros que deseja proteger e crescer. Para fazer isso, você pode entrar em contato com seu banqueiro em seu escritório local. Isso ajuda você a gerenciar, organizar e até mesmo transferir seus recursos otimamente, levando em consideração sua personalidade e sua situação específica. E com todas as soluções que um grande banco pode oferecer. Em suma, uma visão rica de seus recursos.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/sav.jpg" class="flex">
		<h3 class="subheading">Poupança</h3>
		<p>176/5000 Com a nossa grande variedade de títulos de redução de taxa fixa, você pode economizar sabendo que sua taxa é corrigida. Com uma escolha de termos fixos disponíveis, tornamos a economia fácil de operar.</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/mort.jpg" class="flex">
		<h3 class="subheading">Hipotecas</h3>
		<p>Comprar uma nova casa deve ser uma experiência agradável. Gostaríamos de ajudar a fazer desse jeito, levando a preocupação de solicitar uma hipoteca para uma nova casa ou uma casa de propriedade anterior</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/curr.jpg" class="flex">
		<h3 class="subheading">Conta corrente</h3>
		<p>Temos uma gama de contas atuais para atender a todas as necessidades - quer você queira ganhar alto interesse em seu dinheiro, ou use regularmente um descoberto simplesmente quer uma conta direta</p>
		</aside>
		</div>
	</div>
</div>
