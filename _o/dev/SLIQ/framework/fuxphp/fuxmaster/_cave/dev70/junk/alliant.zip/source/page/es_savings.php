<div id="main">
<img src="source/asset/savings.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>Buscamos una lista de proveedores para encontrar la cotización más barata y contamos con centros de llamadas amistosos. Nuestra línea está abierta las 24 horas del día, los 365 días del año para que no tenga que preocuparse si sucede algo inesperado. Tenga en cuenta que los términos y condiciones se aplican.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/regular.jpg" class="flex">
		<h3 class="subheading">Ahorros regulares</h3>
		<p>Obtendrá una tasa fija de 6% AER / bruto si es un cliente Premier o Advance.</p>
		<p>Obtendrá una tasa fija de 4% de AER / bruto si es un cliente de Cuenta Mensual o Graduada</p>
		<p>Usted puede optar por configurar una orden permanente para pagar entre £ 25 y £ 250 en su cuenta de ahorro regular cada mes, hasta un total de £ 3,000</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/fixed.jpg" class="flex">
		<h3 class="subheading">Precios fijos</h3>
		<p>Usted elige un plazo de depósito para su bono de ahorro de tasa fija.</p>
		<p>Usted puede depositar cualquier cosa de £ 2,000 a £ 1,000,000. El dinero está encerrado en el bono durante todo el plazo.<br>
		La tasa de interés depende de la cantidad que deposita y la duración del plazo. Como la tarifa se fija por adelantado, usted sabe exactamente cuánto interés usted ganará al final del término.</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/cashisa.jpg" class="flex">
		<h3 class="subheading">Dinero en efectivo ISA</h3>
		<p>Abra una cuenta en cuestión de minutos y reciba una recompensa por su lealtad cuando pague por lo menos 1 libra esterlina al ISA cada año.<br>
		La tasa de lealtad variable se aplica durante 12 meses * a partir de la fecha de cada pago.</p>
		<p>Al vencimiento de su período de tasa de lealtad, obtendrá una tasa de interés estándar hasta que realice otro pago. Disponible exclusivamente para nuestros clientes.</p>
		</aside>
		</div>

	</div>
</div>
