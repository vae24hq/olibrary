<nav id="nav" class="group">
<h2 class="none">Navigation</h2>
<ul class="menu">
	<li><?php echo makeLink('navlink', 'index', 'home');?></li>
	<li><?php echo makeLink('navlink', 'private');?></li>
	<li><?php echo makeLink('navlink', 'corporate');?></li>
	<li><?php echo makeLink('navlink', 'business');?></li>
	<li><?php echo makeLink('navlink', 'savings');?></li>
	<li><?php echo makeLink('navlink', 'current-account', 'current');?></li>
	<li><?php echo makeLink('navlink', 'insurance');?></li>
	<li><?php echo makeLink('navlink', 'borrowing');?></li>
	<li><?php echo makeLink('navlink', 'mortgages');?></li>
</ul>
</nav>

<div id="contentbox" class="group">
