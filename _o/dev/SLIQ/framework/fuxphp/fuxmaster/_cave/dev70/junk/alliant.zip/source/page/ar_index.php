<div id="main">
<?php loadFile('layout-slide', 'slice');?>
	<div class="content">
		<article id="index">
		<h2 class="heading"><?php global $qs_name; echo $qs_name;?></h2>
		<p>حزمة الأعمال <?php global $qs_acronym; echo $qs_acronym;?> هي أكثر من مجرد حساب مصرفي. سوف تجد خدمات مخصصة إضافية للمهنيين المستقلين والشركات تساعدك على تبسيط الإدارة المالية لعملك أو الشركة.</p>
		</article>

		<div class="group">
		<aside id="inscar">
		<img src="source/asset/corpi.jpg" class="flex">
		<h3 class="subheading">الخدمات المصرفية للشركات</h3>
		<p>لقد وصلنا مع عدد من كبار الخبراء في مجالات معينة لتوفير لكم مع نوع من الخدمات التي يمكن أن تستفيد حقا عملك.</p>
		</aside>

		<aside id="instravel">
		<img src="source/asset/borrow.jpg" class="flex">
		<h3 class="subheading">الاقتراض</h3>
		<p>سواء رغبتك هي للتمويل القصير أو الطويل الأجل، أو لشراء المباني والمركبات، لدينا حل فقط لأجلك، من شأنها أن تضع أكثر من ابتسامة على وجهك.</p>
		</aside>

		<aside id="inshome">
		<img src="source/asset/busi.jpg" class="flex">
		<h3 class="subheading">الخدمات المصرفية للأعمال</h3>
		<p>حسابنا يتيح لك السيطرة الكاملة مع الوصول على مدار الساعة إلى حسابك إما من خلال مرافقنا على الانترنت، وآلات النقدية أو عن طريق البريد.</p>
		</aside>
		</div>
	</div>
</div>
