<div id="main">
<img src="source/asset/corp.jpg" class="flex">
	<div class="content">
		<article id="<?php echo getPage();?>">
		<h2 class="heading"><?php global $qs_acronym; echo $qs_acronym.' '.getPage();?></h2>
		<p>إدارة التدفقات المالية ليست دائما سرير من الورود، وخاصة إذا كانت شركتك هي أيضا نشطة في الخارج. أيضا، <?php echo $qs_acronym;?> يقدم العديد من الأدوات مما يسمح لك لإصلاح كل شيء بسلاسة. نحن نقدم مجموعة من الاحتمالات لإدارة اليومية من المخاوف الرئيسية الخاصة بك: دفع والحصول على أموال.</p>

		<p class="spaceTop">كنت مبتكرة وتستثمر باستمرار في أدوات جديدة للحفاظ على أو زيادة إنتاجية عملك. نحن نقدم مجموعة من الحلول، مصممة خصيصا لاحتياجاتك ومتطلباتك.</p>
		</article>

		<div class="group">
		<aside id="paid">
		<img src="source/asset/get-paid.jpg" class="flex">
		<h3 class="subheading">دفع والحصول على أموال</h3>
		<p>على الرغم من أن نقل يبقى في علاقات B2B وهو الوضع الأكثر شيوعا من تسوية المعاملات الخاصة بك، وهناك خيارات الدفع الأخرى وقواعد مثيرة للاهتمام. أيا كان الخيار الذي تقوم به، <?php echo $qs_acronym;?> دعم لكم في كل من الولايات المتحدة والمملكة المتحدة والخارج.</p>
		</aside>

		<aside id="cash">
		<img src="source/asset/cash-management.jpg" class="flex">
		<h3 class="subheading">إدارة النقود</h3>
		<p>نظرة عامة على حساباتك المختلفة والتوازن العام هو أنها تمثل عنصرا هاما من الإدارة الفعالة لرأس المال الخاص بك.</p>
		</aside>
		</div>
	</div>
</div>
