<?php
// if($fuxURI == 'dashboard'){

// }

#$oRecord['msg'] = isErrorMsg($oRecord['code']);
#$oRecord = oHelper::response($oRecord);
include oDESIGN . 'main.php';
?>