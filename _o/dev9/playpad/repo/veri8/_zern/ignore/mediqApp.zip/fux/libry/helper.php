<?php
class oHelper {
	private static $instance;

	//-------------- Prevent multiple instances ---------------
	private function __construct(){return;}

	//-------------- Prevent duplication ---------------
	private function __clone(){return;}

	//-------------- Returns a single instance ---------------
	public static function instantiate(){
		if(is_null(self::$instance)){
			self::$instance = new self();
		}
		return self::$instance;
	}





/**
 * ===================================================================
 *  [BEGIN] DEVELOPER
 * ===================================================================
 */







	public static function isError($code, $source='', $return='msg'){
		global $oErrorConfig;
		if(!empty($oErrorConfig) && !empty($oErrorConfig[$source]) && is_array($oErrorConfig[$source])){
			$error = $oErrorConfig[$source];
			if($return == 'msg' && array_key_exists($code, $error)){return $error[$code];}
		}
		return '';
	}

	public static function response($resp='', $source=''){
		$output['status'] = ''; $output['code'] = ''; $output['msg'] =''; $output['data'] = '';
		if(!empty($resp['status'])){$output['status'] = $resp['status'];}
		if(!empty($resp['code'])){
			$output['code'] = $resp['code'];
			$resp['msg'] = self::isError($output['code'], $source);
		}
		if(!empty($resp['msg'])){$output['msg'] = $resp['msg'];}
		if(!empty($resp['data'])){$output['data'] = $resp['data'];}
		return $output;
	}







	//-------------- Prepare Notification ---------------
	public static function notify($data=''){
		$code = ''; $msg = '';
		if(isset($data['code'])){$code = $data['code'];}
		if(isset($data['msg'])){$msg = $data['msg'];}

		if(empty($msg)){return false;}

		$type = 'light';
		if(self::isCodeSucess($code, 'E100')){$type = 'light';}
		if(self::isCodeSucess($code, 'E400')){$type = 'warning';}
		if(self::isCodeSucess($code, 'E405 | E401 | E600 | E601')){$type = 'danger';}
		if(self::isCodeSucess($code, 'E200')){$type = 'success';}
		$notify = '<div class="alert alert-'.$type.'" role="alert">'.$msg.'</div>';
		return  $notify;
	}









	public static function isCodeSucess($code, $compare='E200'){
		if(!empty($code)){$code = substr_replace($code , '', -2);}
		if(oText::in($compare, $code)){return true;}
		return false;
	}


	#ToDo
	public static function imgDP($passport='', $sex=''){
		$img = oCLOUD.$passport;
		if(!file_exists($img)){$img = oCLOUD.'noimg.png';}
		return $img;
	}





	public static function dataToRow($data){
		$row = '';
		if(isset($data['data'])){$row = $data['data'];}
		return $row;
	}

	public static function dataInfo($column, $data){
		if(isset($data[$column])){return $data[$column];}
		return false;
	}

	public static function isCSSActive($cssuri='', $currenturi='', $class='active'){
		$css = '';
		if($cssuri == $currenturi){
			$css .= ' '.$class;
		}
		return $css;
	}



	function isActivePage($page=''){
		$activePage = $_SERVER['PHP_SELF'];
		$activePage = basename($activePage);
		if($page == $activePage){return true;}
		return false;
	}

	function cssActive($page=''){
		$output = '';
		if(isActivePage($page)){$output .= ' class="active"';}
		return $output;
	}

} // END HELPER CLASS
?>