 				<div class="container-fluid">

 					<!-- Page Heading -->
 					<h1 class="h3 mb-4 text-gray-800"><?php echo $fuxApp->title();?></h1>


 				</div>