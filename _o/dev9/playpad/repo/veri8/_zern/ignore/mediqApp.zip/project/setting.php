<?php
define('MACHINE_IS', 'dev'); #prod|dev

$oConfig = array();

$oConfig['project'] = 'MediQ';
$oConfig['ver'] = '1.1';

// Database Configuration
$oConfig['db'] = array(
	'name' => 'mediq',
	'user' => 'mediq',
	'pass' => 'OpenMediQ',
	'host' => 'localhost',
	'driver' => 'PDO' #MySQLi/PDO
);

// Configure Base URL & Path
$oBaseURL['mediq'] = '127.0.0.1';
// $oBaseURL['open'] = 'mediq.ae';

// Allowed URIs
$oConfig['uri_allowed'] = array(
	'default' => 'mediq',
	'index' => '',
	'login' => '',
	'logout' => '',
	'dashboard' => '',

	'new-card' => '',
	'cards' => 'card',
	'card' => 'card',
	'update-card' => 'card',

	'new-case' => 'case',

	'bill' => 'bill',
	'bill-payment' => 'bill',
	'payment' => 'bill',

	
	'blank' => '',
	'modify-password' => '',	
);
?>