
			<hr class="sidebar-divider">
			<div class="sidebar-heading">Settings</div>
				<li class="nav-item<?php echo oHelper::isCSSActive('modify-password', $fuxURI);?>"><a class="nav-link" href="modify-password"><i class="fas fa-fw fa-cog"></i><span>Modify Password</span></a></li>
				<li class="nav-item">
					<a class="nav-link" href="logout" data-toggle="modal" data-target="#logoutModal"><i class="fas fa-fw fa-sign-out-alt"></i>
						<span>Logout</span>
					</a>
			</li>
