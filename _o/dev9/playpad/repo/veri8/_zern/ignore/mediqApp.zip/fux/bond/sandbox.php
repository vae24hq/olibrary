<?php
function new_user($user='odao', $type='dev'){
	echo 'SANDBOX <hr>';
	global $fuxAuth;
	$result['puid'] = oHelper::randomiz('puid');
	$result['ruid'] = oHelper::randomiz('ruid');
	$result['email'] = $user.'@pear.ca';
	$result['username'] = $fuxAuth->docrypt($user, 'encode');
	$result['password'] = $fuxAuth->docrypt(ucfirst($user).'10#', 'crypt');
	$result['pin'] = mt_rand(00000, 99999);
	$result['type'] = $fuxAuth->docrypt($type, 'encode');

	oHelper::dbugA($result);
	exit;
}


function newRecord(){
	echo 'SANDBOX <hr>';
	global $fuxAuth;
	$result['puid'] = oHelper::randomiz('puid');
	$result['ruid'] = oHelper::randomiz('ruid');
	oHelper::dbug($result);
	exit;
}
// new_user();
// newRecord();
?>