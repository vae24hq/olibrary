<?php
//========== DIRECTOR STRUCTURE (directory path)==========//
# Define ENGINE DS
defined('oENGINE') ? null : define('oENGINE', oBASEPATH.'fux'.DS);
	defined('oBOND') ? null : define('oBOND', oENGINE.'bond'.DS);
	defined('oLIBRY') ? null : define('oLIBRY', oENGINE.'libry'.DS);


# Define PROJECT DS
defined('oPROJECT') ? null : define('oPROJECT', oBASEPATH.'project'.DS);
	defined('oCLOUD') ? null : define('oCLOUD', oPROJECT.'cloud'.DS);

	defined('oSUITE') ? null : define('oSUITE', oPROJECT.'suite'.DS);
		defined('oAPI') ? null : define('oAPI', oSUITE.'api'.DS);
		defined('oMODEL') ? null : define('oMODEL', oSUITE.'modelizr'.DS);
		defined('oRGANIZ') ? null : define('oRGANIZ', oSUITE.'organizr'.DS);
		defined('oUTIL') ? null : define('oUTIL', oSUITE.'utilizr'.DS);

	defined('oINTERFACE') ? null : define('oINTERFACE', oPROJECT.'ui'.DS);
		defined('oDESIGN') ? null : define('oDESIGN', oINTERFACE.'design'.DS);
		defined('oLAYOUT') ? null : define('oLAYOUT', oINTERFACE.'layout'.DS);
			defined('oBIT') ? null : define('oBIT', oLAYOUT.'bitzr'.DS);
			defined('oSLICE') ? null : define('oSLICE', oLAYOUT.'slicezr'.DS);
			defined('oVIEW') ? null : define('oVIEW', oLAYOUT.'viewzr'.DS);


# Using HTACCESS for PATH
defined('ASSET') ? null : define('ASSET', 'asset'.PS);
defined('CSS') ? null : define('CSS', 'css'.PS);
defined('ICON') ? null : define('ICON', 'icon'.PS);
defined('JS') ? null : define('JS', 'js'.PS);
defined('AUDIO') ? null : define('AUDIO', 'audio'.PS);
defined('DOCUMENT') ? null : define('DOCUMENT', 'js'.PS);
defined('GRAFIX') ? null : define('GRAFIX', 'grafix'.PS);
defined('VIDEO') ? null : define('VIDEO', 'video'.PS);
defined('PLUGIN') ? null : define('PLUGIN', 'plugin'.PS);
defined('CLOUD') ? null : define('CLOUD', 'cloud'.PS);
?>