
			<hr class="sidebar-divider">
			<div class="sidebar-heading">Payment & Bill</div>
				<li class="nav-item"><a class="nav-link" href="new-bill?type=newcard"><i class="fas fa-fw fa-book"></i><span>New Card</span></a></li>
				<li class="nav-item"><a class="nav-link" href="cards"><i class="fas fa-fw fa-book"></i><span>Make Payment</span></a></li>
