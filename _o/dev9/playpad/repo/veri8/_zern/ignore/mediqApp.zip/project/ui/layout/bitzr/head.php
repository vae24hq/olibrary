<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title><?php echo $fuxApp->title();?></title>
	<link rel="icon" type="image/x-icon" href="icon/favicon.ico">
	<!-- Custom fonts for this template-->
	<link href="css/fontawesome.css" rel="stylesheet" type="text/css">
	<link href="css/google.css" rel="stylesheet" type="text/css">
	<!-- Custom styles for this template-->
	<link href="css/fux.css" rel="stylesheet" type="text/css">
	<link href="css/dataTable.css" rel="stylesheet" type="text/css">
</head>