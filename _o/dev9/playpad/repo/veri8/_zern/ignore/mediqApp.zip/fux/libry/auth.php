<?php
class oAuth {
	private static $instance;
	private $connection;
	// private static $auth;

	//-------------- Prevent multiple instances ---------------
	public function __construct($connection){
		if(is_object($connection)){$this->connection = $connection;}
		else {
			die('Auth:: requires connection - #E1001');
		}
	}

	//-------------- Prevent duplication ---------------
	private function __clone(){return;}

	//-------------- Returns a single instance ---------------
	public static function instantiate($connection){
		if(is_null(self::$instance)){
			self::$instance = new self($connection);
		}
		return self::$instance;
	}



	public static function password($password){
		return password_hash($password, PASSWORD_BCRYPT);
	}


	public static function isPassword($password, $hash){
		if(password_verify($password, $hash)){return true;}
		return false;
	}


	public static function docrypt($string, $action='encode'){
		if($action=='encode'){
			return base64_encode($string);
		}
		elseif($action=='decode'){
			return base64_decode($string);
		}
		elseif($action == 'encrypt' || $action == 'decrypt'){
			$key = 'ababio';
			// $cipher = "aes-128-gcm";
			$crypto = new Crypto($key);
			if($action == 'encrypt'){
				return $crypto->encrypt($string);
			}
			elseif($action == 'decrypt'){
				return $crypto->decrypt($string);
			}
		}
		elseif($action == 'crypt'){
			return self::password($string);
		}
		elseif($action == 'crypt_verify' && is_array($string)){
			if(isset($string['string'])){$input = $string['string'];}
			if(isset($string['hash'])){$hash = $string['hash'];}

			if(!empty($input) && !empty($hash)){
				return self::isPassword($input, $hash);
			}
		}
	}


	//-------------- timeout user session  ---------------
	public static function timeout($duration='1800', $auto='yeap'){
		if($auto == 'yeap'){oURL::redirect( 'login', ($duration));}
		else {	
			oSession::start();
			if(isset($_SESSION['LAST_ACT']) && (time() - $_SESSION['LAST_ACT'] > $duration)){
				oSession::restart();
			}
			$_SESSION['LAST_ACT'] = time();
		}
	}





	//-------------- user information  ---------------
	public function user($puid, $column='*'){
		#global $fuxCRUD;
		$db = $this->connection;
		$condition['puid'] = $puid;
		$user = $db->findSQL($column, 'user', $condition, 'record');
		if(!isset($user['QUERY_FAILED'])){
			return $user;
		}
		#Todo ~ log error resulting from QUERY [on production, die on development]
		return false;
	}


	//-------------- validating user's session  ---------------
	public function is(){
		#Require login
		oSession::start();
		if(empty($_SESSION['user'])){
			oURL::redirect('login');
		}
		else {
			#validate active user & return information
			$user = $this->user($_SESSION['user'], 'puid');
			if($user === false){
				#Todo ~ log when IMPROBABLE CASE Occurs
				oURL::redirect('login');
			}
			elseif($user == 'NO_RECORD'){
				$this->logout('login');
			}
			elseif(!empty($user['puid'])){
				#return $user;
				return;
			}
		}
	}


	//-------------- login user ---------------
	public function login($userid, $password){
		$query = 'SELECT `puid`, `type`, `password` FROM `user`';
		$query .=" WHERE '".$userid."' IN (`email`,`phone`, `username`)";
		$query .= " OR `username` = '".self::docrypt($userid, 'encode')."'";
		$query .=' LIMIT 1';

		$db = $this->connection;
		$result = $db->runSQL($query, 'record');

		if(isset($result['QUERY_FAILED'])){
			#TODO ~ log error resulting from QUERY [on production, die on development]
			$response['code'] = 'E600B2';
		}
		else {
			if($result == 'NO_RECORD'){$response['code'] = 'E401A2';}
			elseif($result === false){$response['code'] = 'E600B3';}
			elseif(is_array($result) && !empty($result['puid']) && !empty($result['password'])){
				if(!self::isPassword($password, $result['password'])){$response['code'] = 'E401A3';}
				else {
					$response['code'] = 'E200A1';
					oSession::start();
					$_SESSION['user'] = $result['puid'];
					$response['data'] = $_SESSION['user'];
				}
			} else {
				$response['code'] = 'E600B4';
			}
		}
		return $response;
	}


	//-------------- logout user  ---------------
	public function logout($uri='login'){
		#@Todo ~ collect user and record logout information
		oSession::start();
		if(isset($_SESSION['user'])){
			oSession::delete('user');
		}
		oSession::restart();
		if(!empty($uri)){
			oURL::redirect($uri);
		}
	}



	//-------------- Session's active User  ---------------
	public function userActive($column='*'){
		if(!empty($_SESSION['user'])){
			$condition['puid'] = $_SESSION['user'];
			$db = $this->connection;
			$user = $db->findSQL($column, 'user', $condition, 'record');
			if(!isset($user['QUERY_FAILED'])){
				if(isset($user['password'])){unset($user['password']);}
				if(!empty($user['username'])){$user['username'] = self::docrypt($user['username'], 'decode');}
				if(!empty($user['type'])){$user['type'] = self::docrypt($user['type'], 'decode');}
				return $user;
			}
			#Todo ~ log error resulting from QUERY [on production, die on development]
			return false;
		}
	}


	//-------------- Update user's password  ---------------
	public function passwordUpdate($puid, $password, $newpassword){
		$SQL = "SELECT `puid`, `password` FROM `user` WHERE `puid` = '".$puid."' LIMIT 1";
		$db = $this->connection;
		$result = $db->runSQL($SQL, 'record');

		if(isset($result['QUERY_FAILED'])){
			#TODO ~ if Query failed
			$response['code'] = 'E600B2';
		}
		else {
			if($result == 'NO_RECORD'){$response['code'] = 'E405A2';}
			elseif($result === false){$response['code'] = 'E600B3';}
			elseif(is_array($result) && !empty($result['puid']) && !empty($result['password'])){
				if(!self::isPassword($password, $result['password'])){$response['code'] = 'E401A1';}
				else {
					#update new password
					$data = array(); $cond = array();
					$newpassword = self::password($newpassword);
					$data['password'] = $newpassword;
					$cond['puid'] = $puid;
					$updatePW = $db->updateSQL($data, 'user', $cond, 1);
					if($updatePW === 1){
						$response['data'] = $_SESSION['user'];
						$response['code'] = 'E200A1';
						oSession::restart();
						oURL::redirect('login?refresh=yeap', 5);
					}
					else {
						$response['code'] = 'E601A1';
					}
				}
			} else {
				$response['code'] = 'E600B4';
			}
		}

		return $response;
	}

	




	public static function isCrypt($crypted, $verify){
		$string = self::crypt($crypted, 'decrypt');
		if($string == $verify){return true;}
		return false;
	}

	public static function restrict($input, $verify, $isCrypt='yeap', $redirect=''){
		if($isCrypt == 'yeap'){
			$valid = self::isCrypt($input, $verify);
			if(!$valid && !empty($redirect)){URL::redirect($redirect);}
			elseif(!$valid){return true;}
		}
		elseif($input != $verify){
			if(!empty($redirect)){URL::redirect($redirect);}
			return true;
		}

		#false indicates that access should not be restricted
		return false;
	}
}
?>