<?php
//========== LIBRARY ==========//
require oPROJECT.'setting.php';
require oLIBRY.'file.php';
oFile::inc(oLIBRY.'session');
oFile::inc(oLIBRY.'crypto');
oFile::inc(oLIBRY.'text');
oFile::inc(oLIBRY.'helper');
oFile::inc(oLIBRY.'url');
oFile::inc(oLIBRY.'input');
oFile::inc(oLIBRY.'fux');
oFile::inc(oLIBRY.'crud');
oFile::inc(oLIBRY.'auth');
?>