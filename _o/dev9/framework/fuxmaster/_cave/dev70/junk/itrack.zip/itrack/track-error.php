
<p style="color: red; background: black; margin: 5px 10px; padding: 4px; text-shadow: none;">Please enter a valid tracking number</p>