
<div class="row">
  <ol class="breadcrumb">
    <li><a href="./"><i class="fa fa-home fa-lg" aria-hidden="true"></i></a></li>
    <li class="active">404 Error</li>
  </ol>
</div>
<!--/.row-->

<p class="spacer">&nbsp;</p>
<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
      <div class="panel-heading">404 Error</div>
      <div class="panel-body">
        <p>We are sorry for this awkwardness but the document you requested could not be served.<br>
          You may return to your <a href="./" title="dashboard">dashboard</a> or send an email to <span class="text-primary">admin@eirvo.ga</span> </p>
      </div>
    </div>
  </div>
</div>
