

<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
	<ul class="nav menu">
		<li<?php activeCSS('dashboard');?>><a href="?link=dashboard"><i class="fa fa-truck" aria-hidden="true"></i>Manage Tracking</a></li>
		<li<?php activeCSS('clients');?>><a href="?link=add-tracking"><i class="fa fa-paper-plane" aria-hidden="true"></i>Create Tracking</a></li>
		<li role="presentation" class="divider"></li>
		<li><a href="admin-login.php?process=logout"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a></li>
	</ul>
</div>
<!--/.sidebar-->
