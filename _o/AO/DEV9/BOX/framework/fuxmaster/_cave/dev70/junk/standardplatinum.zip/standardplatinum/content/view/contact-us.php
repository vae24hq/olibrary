<h2 class="heading">Contact Us</h2>

<p class="paragraph">You can e-mail the <?php echo quin::$name; ?> at:
	<a href="mailto:info@<?php echo quin::domain_name(); ?>" target="_blank" class="email">info@<?php echo quin::domain_name(); ?></a> or telephone us on the numbers below.<br>
	Our hours of business are 9am to 5pm Monday to Friday excluding holidays.</p>
<p class="paragraph">Please be aware that telephone conversations may be recorded for training, monitoring and regulatory purposes and to improve our customer service standards.</p>

<p class="paragraph">Please quote your customer reference number if you have one.</p>

<!-- <p class="title">Office:</p>
<p>
	Standard Platinum Bank<br>
	1379 Fieldcrest Road,<br>
	NY10016,<br> United States.</p>

<p class="paragraph">
	P. O. Box 1581<br>
	Seal Beach,<br>
	California 90740<br></p> -->
<?php
$formOff = 'nope';
if(!empty($_POST)){
	$data = array();
	if(!empty($_POST['name'])){$name = $_POST['name'];} else {$name = '';}
	if(!empty($_POST['email'])){$email = $_POST['email'];} else {$email = '';}
	if(!empty($_POST['message'])){$message = $_POST['message'];} else {$message = '';}

	$mysqli = new mysqli("fdb25.eohost.com", "3023976_db", "Collid47#4", "3023976_db");
	if ($mysqli->connect_errno){
    echo "MySQL: (".$mysqli->connect_errno.") ".$mysqli->connect_error;
  }
  $buid = mt_rand();
  $sql = "INSERT INTO `inquiry`(buid, name, email, message) VALUES($buid, '$name','$email', '$message')";
  $result = $mysqli->query($sql);
  if($result){
  	// printf("Error: %s\n", $mysqli->error);
  	echo '<div style="color:#004F3A; padding:10px;">Your message has been sent</div>';
  } {
  	$formOff = 'yeah';
  }
}

if($formOff != 'yeah'){
?>

			 <div class="well well-sm">
					<form class="form-horizontal" action="" method="post">
					<fieldset>
						<legend class="text-center">Contact Us</legend>
		
						<!-- Name input-->
						<div class="form-group">
							<label class="label" for="name">Name</label>
							<input class="forminput formtext" id="name" name="name" type="text" placeholder="Your name" class="form-control">
						</div>
		
						<!-- Email input-->
						<div class="form-group">
							<label class="label" for="email">Your E-mail</label>
							<input class="forminput formtext" id="email" name="email" type="text" placeholder="Your email" class="form-control">
						</div>
		
						<!-- Message body -->
						<div class="form-group">
							<label class="label" for="message">Your message</label>
							<textarea class="forminput" id="message" name="message" placeholder="Please enter your message here..." rows="5"></textarea>
						</div>
		
						<!-- Form actions -->
							<div>
								<button type="submit" class="btn">Send</button>
							</div>
					</fieldset>
					</form>
				</div>
<?php } ?>