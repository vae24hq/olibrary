<footer id="footer">
	<div class="content">

	<div class="centeredmenu">
		<ul>
		<li><?php echo page_menu('index', 'home');?></li>
		<li><?php echo page_menu('about-us', 'about us');?></li>
		<li><?php echo page_menu('contact-us', 'contact us');?></li>
		</ul>
	</div>

	<p><?php echo quin::$name;?> is an Authorised Institution under the Financial Services and Markets Act 2000.<br>
	We are authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority.</p>
	</div>
</footer>