
<div id="itop">
<div class="itop group">
	<span class="ifirm left"><?php echo firm('name');?></span>
	<span class="idate right"><?php echo date ("l, F j, Y");?></span>
</div>
</div>

<header id="iheader">
<div class="iheader group">
	<img class="inetlogo right" src="../brux/inetb.png" alt="iNetB">
</div>
</header>
