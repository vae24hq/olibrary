<?php require('brux.php');?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Welcome to <?php echo firm('name');?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="favicon.ico">
</head>

<body>
	<p>
		<?php echo showGreeting();?><br><br>
		It is nice to know that you are there for us.<br>
		Thank you for visiting.
	</p>
</body>
</html>
