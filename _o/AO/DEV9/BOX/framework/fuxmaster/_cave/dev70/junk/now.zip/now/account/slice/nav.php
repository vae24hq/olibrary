
<nav id="navigation">
	<div class="navigation group">
		<ul class="nav">
			<li><a href="dashboard.php" target="content" class="link">My Account</a></li>
			<li><a href="transaction.php" target="content" class="link">Transactions</a></li>
			<li><a href="transfer.php" target="content" class="link">Transfer Funds</a></li>
			<li><a href="upload.php" target="content" class="link">Upload Photo</a></li>
			<li><a href="profile.php" target="content" class="link">Manage Profile</a></li>
			<li><a href="nok.php" target="content" class="link">Update NOK</a></li>
			<li><a href="setting.php" target="content" class="link">Settings</a></li>
			<li><a href="<?php echo $logoutAction;?>" class="link">Logout</a></li>
		</ul>
	</div>
</nav>
