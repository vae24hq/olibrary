<nav id="nav" class="group">
<h2 class="hide">Navigation</h2>
	<div class="content group">
	<ul class="navigation">
		<li><?php echo page_menu('index', 'home');?></li>
		<li><?php echo page_menu_group('about-us', 'about us', 'jhiam');?></li>
		<li><?php echo page_menu('personal');?></li>
		<li><?php echo page_menu('commercial');?></li>
		<li><?php echo page_menu('financial', 'financial information');?></li>
		<li><?php echo page_menu('recruitment');?></li>
		<li><?php echo page_menu('contact-us', 'contact us');?></li>
	</ul>
	</div>
</nav>