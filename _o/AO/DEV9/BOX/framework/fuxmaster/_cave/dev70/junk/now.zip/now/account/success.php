<?php require('../brux.php'); require('is_restrict.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Success :: iNetB - <?php echo firm('name');?></title>
<?php include('../in_head.php');?>
</head>

<body>
<!-- BEGIN LAYOUT FOR SUCCESS -->
<div id="content">
	<div class="col-md-12">
		<div class="table-responsive">
		<p class="text-success" style="margin: 80px auto; text-align: center">Your action was successfully completed.</p>
		</div>
	</div>
</div>
</body>
</html>