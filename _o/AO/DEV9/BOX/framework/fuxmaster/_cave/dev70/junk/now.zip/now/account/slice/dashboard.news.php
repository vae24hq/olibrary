
		<table id="newsInfo" class="record col-md-12">
			<tr>
				<th class="col-md-12 table-heading" colspan="12">News on Account</th>
			</tr>
			<tr>
				<td class="col-md-8 value" colspan="8">
				<div style="min-height: 100px;">
					<p><?php echo nl2br(rewriteRH($userInfo['statement']));?></p>
				</div>
				</td>
			</tr>
		</table>
