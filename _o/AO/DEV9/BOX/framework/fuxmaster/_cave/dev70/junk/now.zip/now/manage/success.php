<?php require('../brux.php'); require('is_restrict.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Administrator - Success</title>
<?php include('../in_head.php');?>
</head>

<body>
	<?php require('slice/header.php');?>
	<h1 class="heading">Success</h1>
	<div class="container">
	<div class="page">
		<p class="text-success" style="margin: 80px auto; text-align: center">Your action was successfully completed.</p>
	</div>
	</div>
<?php include('slice/footer.php'); include('../in_foot.php');?>
</body>
</html>