
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="../favicon.ico">
<link href="../brux/bootstrap.css" rel="stylesheet">
<link href="../brux/ux.css" rel="stylesheet">
<!--[if lt IE 9]>
<script src="../brux/html5.js"></script>
<script src="../brux/respond.js"></script>
<![endif]-->

