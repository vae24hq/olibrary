<header id="header">
	<div class="content group">
		<a href="./" class="logo"><img src="asset/logo.png" alt="<?php echo quin::$name;?> logo" class="logo"></a>
		<div class="topbar">
			<a href="#" class="toplink" title="register" onclick="quinOpen('register.php')">Register</a><a href="#" class="toplink" title="login" onclick="quinOpen('login.php')">Login</a>
		</div>
	</div>
</header>