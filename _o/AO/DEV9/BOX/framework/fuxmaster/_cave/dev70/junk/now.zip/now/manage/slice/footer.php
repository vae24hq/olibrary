
	<div class="container" style="line-height: 2.5;"><a href="javascript:history.go(-1);">Back</a> | <a href="javascript:location.reload()">Refresh</a></div>

