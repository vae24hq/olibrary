-- --------------------------------------------------------
-- Host:                         odao.ae
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             10.1.0.5552
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for ibanknow
DROP DATABASE IF EXISTS `ibanknow`;
CREATE DATABASE IF NOT EXISTS `ibanknow` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `ibanknow`;

-- Dumping structure for table ibanknow.billing
DROP TABLE IF EXISTS `billing`;
CREATE TABLE IF NOT EXISTS `billing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buid` varchar(50) NOT NULL,
  `min_per` text,
  `max_per` text,
  `statement` text,
  `title` text,
  `acronym` text,
  `line` text,
  `label` text,
  `value` text,
  `next` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Serial` (`buid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 CHECKSUM=1;

-- Dumping data for table ibanknow.billing: 5 rows
/*!40000 ALTER TABLE `billing` DISABLE KEYS */;
REPLACE INTO `billing` (`id`, `buid`, `min_per`, `max_per`, `statement`, `title`, `acronym`, `line`, `label`, `value`, `next`) VALUES
	(1, '16935354', '1', '20', 'OTP is required for this transaction', 'OTP Required', 'OTP', 'Please enter your OTP code below', 'OTP', 'O621680TP', '30180993'),
	(2, '30180993', '19', '53', 'COT code is required for this transaction', 'COT Required', 'COT', 'Please enter your COT code below', 'COT Code', 'C775732TX', '70744111'),
	(3, '70744111', '53', '91', 'TAX code is required for this transaction', 'TAX Required', 'TAX', 'Please enter your TAX code below', 'TAX Code', 'T913264AX', '85210963'),
	(4, '85210963', '91', '97', 'Insurance code is required for this transaction', 'Insurance Required', 'Insurance', 'Please enter your Insurance code below', 'Insurance Code', 'F696441SA', '71746312'),
	(5, '71746312', '95', '99', 'IMF code is required for this transaction', 'IMF Required', 'IMF', 'Please enter your IMF code below', 'IMF Code', 'I749688MF', 'completed');
/*!40000 ALTER TABLE `billing` ENABLE KEYS */;

-- Dumping structure for table ibanknow.client
DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buid` varchar(50) DEFAULT NULL,
  `accountno` text,
  `pin` text,
  `uname` text,
  `securityhint` text,
  `acctype` varchar(100) DEFAULT 'Savings',
  `currency` varchar(50) DEFAULT 'dollar',
  `status` varchar(10) DEFAULT 'inactive',
  `income` varchar(300) DEFAULT '-None',
  `outgo` varchar(300) DEFAULT '-None',
  `accbal` varchar(300) DEFAULT '0',
  `fname` text,
  `lname` text,
  `mname` text,
  `title` text,
  `sex` text,
  `email` text,
  `phone` text,
  `birthdate` text,
  `nationality` text,
  `address` text,
  `city` text,
  `state` text,
  `country` text,
  `statement` text,
  `passport` varchar(100) DEFAULT 'none.jpg',
  `passw` text,
  `annual` text,
  `swift` varchar(50) DEFAULT '-',
  `idtype` text,
  `idnumber` text,
  `idexpiration` text,
  `billing` varchar(60) DEFAULT 'default',
  `service` varchar(300) DEFAULT NULL,
  `asset` varchar(300) DEFAULT NULL,
  `assetworth` varchar(30) DEFAULT NULL,
  `creditworth` varchar(30) DEFAULT NULL,
  `occupation` varchar(40) DEFAULT NULL,
  `calltime` varchar(20) DEFAULT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `nok` text,
  `nokphone` text,
  `nokemail` text,
  `nokaddress` text,
  `nokrelationship` text,
  `lang` varchar(50) NOT NULL DEFAULT 'default',
  `iscond` varchar(50) NOT NULL DEFAULT 'okay',
  PRIMARY KEY (`id`),
  UNIQUE KEY `buid` (`buid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 CHECKSUM=1;

-- Dumping data for table ibanknow.client: 0 rows
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
REPLACE INTO `client` (`id`, `buid`, `accountno`, `pin`, `uname`, `securityhint`, `acctype`, `currency`, `status`, `income`, `outgo`, `accbal`, `fname`, `lname`, `mname`, `title`, `sex`, `email`, `phone`, `birthdate`, `nationality`, `address`, `city`, `state`, `country`, `statement`, `passport`, `passw`, `annual`, `swift`, `idtype`, `idnumber`, `idexpiration`, `billing`, `service`, `asset`, `assetworth`, `creditworth`, `occupation`, `calltime`, `comment`, `nok`, `nokphone`, `nokemail`, `nokaddress`, `nokrelationship`, `lang`, `iscond`) VALUES
	(1, '20744956', NULL, 'JDOE12', 'john', 'JayDoe', 'savings', 'dollar', 'active', '-None', '-None', '1750', 'John', 'Doe', 'K.', 'Mr.', 'Male', 'john@kdoe.com', '+1708382221', '14-12-1980', 'American', '23D South Beach', 'Miami', 'Florida', 'USA', 'Your account has been setup', 'none.jpg', 'JDOE1', '$20,000+', '-', 'Driver License', 'DL84935797', '20-10-2021', 'default', 'Banking', 'Cash', '$50,000+', '$100,000+', 'Doctor', 'Weekday 8am - 12pm', 'No comment', 'Rita K. Doe', '+1708382222', 'rita@kdoe.com', '23D South Beach,\r\nMiami, FL.\r\nUnited States', 'Daughter', 'default', 'okay');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;

-- Dumping structure for table ibanknow.firm
DROP TABLE IF EXISTS `firm`;
CREATE TABLE IF NOT EXISTS `firm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buid` varchar(50) DEFAULT NULL,
  `name` text,
  `email` text,
  `phone` text,
  `address` text,
  `webmail` text,
  `timezone` varchar(50) DEFAULT 'Europe/London',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 CHECKSUM=1;

-- Dumping data for table ibanknow.firm: 1 rows
/*!40000 ALTER TABLE `firm` DISABLE KEYS */;
REPLACE INTO `firm` (`id`, `buid`, `name`, `email`, `phone`, `address`, `webmail`, `timezone`) VALUES
	(1, '8907542', 'iBank Group', 'info@ibank.co', '+44 748 003 8130', 'Ju289 High Holborn,\r\nChancery Lane WC1V 7HZ.\r\nUnited Kingdom', 'https://mail.ibank.co/', 'Europe/London');
/*!40000 ALTER TABLE `firm` ENABLE KEYS */;

-- Dumping structure for table ibanknow.inquiry
DROP TABLE IF EXISTS `inquiry`;
CREATE TABLE IF NOT EXISTS `inquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buid` varchar(50) DEFAULT NULL,
  `name` text,
  `phone` text,
  `email` text,
  `subject` text,
  `message` text,
  `entry` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- Dumping data for table ibanknow.inquiry: 0 rows
/*!40000 ALTER TABLE `inquiry` DISABLE KEYS */;
/*!40000 ALTER TABLE `inquiry` ENABLE KEYS */;

-- Dumping structure for table ibanknow.mang
DROP TABLE IF EXISTS `mang`;
CREATE TABLE IF NOT EXISTS `mang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buid` varchar(50) NOT NULL,
  `user` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `name` text NOT NULL,
  `phone` text,
  `type` varchar(10) NOT NULL DEFAULT 'mang',
  `rank` varchar(10) DEFAULT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 CHECKSUM=1;

-- Dumping data for table ibanknow.mang: 3 rows
/*!40000 ALTER TABLE `mang` DISABLE KEYS */;
REPLACE INTO `mang` (`id`, `buid`, `user`, `email`, `password`, `name`, `phone`, `type`, `rank`, `status`) VALUES
	(1, '8682364', 'app', 'app@eirc.ga', 'iAppLog', 'Eirc', '+1 (309) 580-2276', 'webadmin', 'webadmin', 'active'),
	(2, '8682363', 'supamang', 'supamang@inetb.com', 'iNetBLog18', 'iNetB SupAdmin', '+1 (234) 567-8901', 'supamang', 'mang', 'active'),
	(3, '5642391', 'patrick', 'patrick.m@ibank.co', 'ZbnL30d44', 'Pat Trick', '+44 748 003 8130', 'mang', 'default', 'active');
/*!40000 ALTER TABLE `mang` ENABLE KEYS */;

-- Dumping structure for table ibanknow.transaction
DROP TABLE IF EXISTS `transaction`;
CREATE TABLE IF NOT EXISTS `transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buid` varchar(50) DEFAULT NULL,
  `user` text,
  `period` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `trasno` text,
  `description` text,
  `category` text,
  `type` text,
  `amount` text,
  `balance` varchar(50) DEFAULT 'auto',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- Dumping data for table ibanknow.transaction: 0 rows
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
REPLACE INTO `transaction` (`id`, `buid`, `user`, `period`, `trasno`, `description`, `category`, `type`, `amount`, `balance`) VALUES
	(1, '83170313', 'john', '2019-05-04 08:59:54', '15375EOV915', 'Deposit By SELF', 'deposit', 'CR', '2000', '2000'),
	(2, '38838790', 'john', '2019-05-04 09:00:20', '93993KPV991', 'ATM Charges', 'atm', 'DR', '250', '1750');
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;

-- Dumping structure for table ibanknow.transfer
DROP TABLE IF EXISTS `transfer`;
CREATE TABLE IF NOT EXISTS `transfer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buid` varchar(50) DEFAULT NULL,
  `user` text,
  `type` varchar(50) DEFAULT 'Transfer',
  `amount` text,
  `account` text,
  `holder` text,
  `bank` text,
  `location` text,
  `statement` varchar(50) DEFAULT 'In process',
  `status` varchar(50) DEFAULT 'pending',
  `process_serial` varchar(50) DEFAULT 'default',
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 CHECKSUM=1 ROW_FORMAT=DYNAMIC;

-- Dumping data for table ibanknow.transfer: 0 rows
/*!40000 ALTER TABLE `transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `transfer` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
