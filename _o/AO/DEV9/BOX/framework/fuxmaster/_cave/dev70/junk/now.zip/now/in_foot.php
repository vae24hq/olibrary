
	<footer class="footer">
		<div class="container">&copy; iNetB 2018 | <span class="firm"><?php echo firm('name');?></span></div>
	</footer>

	<script src="../brux/jquery.js"></script>
	<script src="../brux/bootstrap.js"></script>
	<script src="../brux/workaround.js"></script>
