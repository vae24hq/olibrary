<div id="banner">
	<div class="content">
		<div id="tagline" class="group">
			<p class="tagline">Earn up to <span class="emphasis">2.50%</span> Gross with the Capital Millennium Bond from <span class="emphasis"><?php echo quin::$name;?></span></p>
			<p class="badge"><img src="asset/badge.png" class="badge-logo"></p>
		</div>
	</div>
</div>