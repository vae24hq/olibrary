<li class="mdc-list-item" role="menuitem">
	<div class="item-thumbnail item-thumbnail-icon-only"> <i class="mdi mdi-account-edit text-primary"></i> </div>
	<div class="item-content d-flex align-items-start flex-column justify-content-center">
		<h6 class="item-subject font-weight-normal" onClick="window.location.href='/settings';">Settings</h6>
	</div>
</li>
<li class="mdc-list-item" role="menuitem">
	<div class="item-thumbnail item-thumbnail-icon-only"> <i class="mdi mdi-logout-variant text-primary"></i> </div>
	<div class="item-content d-flex align-items-start flex-column justify-content-center">
		<h6 class="item-subject font-weight-normal" onClick="window.location.href='/logout';">Logout</h6>
	</div>
</li>