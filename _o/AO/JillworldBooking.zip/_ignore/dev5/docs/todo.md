ROUTING
	-Links
	-Views
	-Forms
MYSQL

Clean Route/Link


DONE
==========================
 -Redirecting
 -Language (URL)