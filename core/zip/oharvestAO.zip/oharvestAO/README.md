# oHarvestAO
oHarvestPad

FLOW
1. Register/Login
2. Select Parish & Manager Status

SEED


PLEDGES
1. List of All Pledges [member]
2. Make Pledge
3. Redeem Pledge (payment)


PING
	/ping-success?okey=40zqD0deYpGQIHumiXsn&platform=webapi&ojson

	/ping-failed?okey=40zqD0deYpGQIHumiXsn&platform=webapi&ojson

REGISTER
	/register?okey=40zqD0deYpGQIHumiXsn&platform=webapi&ojson
