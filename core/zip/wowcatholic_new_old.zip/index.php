<?php
$model = array();
require 'ao.ignit.inc';
require(oCORE.'init.inc');
if(is_array($model)){$resp = array_merge($resp, $model);}

#OUTPUT
if(oFile::InCheck(oCORE.oVIEWZR.$uri.'.inc'));
require(oCORE.oVIEWZR.$uri.'.inc');
?>