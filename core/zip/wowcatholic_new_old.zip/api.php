<?php
$model = array();
require 'ao.ignit.inc';
require(oCORE.'init.inc');
if(is_array($model)){$resp = array_merge($resp, $model);}

#OUTPUT RESPONSE
if(!isset($_REQUEST['ojson'])){
	echo oPrint::Neat($resp);
	return;
} else {
	return oJson::Display($resp);
}
?>